﻿using Neaproject.Data;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace Neaproject.Functions
{
    public class FindAvailableSlots
    {
        private readonly SqliteDataAccess _db;

        public FindAvailableSlots(SqliteDataAccess db)
        {
            _db = db;
        }

        public List<AvailableDate> FindAvailableDates(
            string jobId,
            List<DayOfWeek> selectedDays,
            int timeFrame,
            int maxResults = 5)
        {
            var today = DateTime.Today;
            var availableDates = new List<AvailableDate>();

            using (var connection = _db.GetConnection())
            {
                connection.Open();

                string jobRegion =
                    GetJobRegion(connection, jobId);

                for (int offset = 1; offset <= timeFrame; offset++)
                {
                    DateTime currentDate =
                        today.AddDays(offset);

                    if (!selectedDays.Contains(currentDate.DayOfWeek))
                    {
                        continue;
                    }

                    bool amSlotTaken = false;
                    bool pmSlotTaken = false;
                    string? existingRegion = null;

                    using (var slotCheckSql = new SQLiteCommand(@"
                        SELECT A.TimeSlot, J.Location
                        FROM Appointments A
                        JOIN Jobs J ON A.JobID = J.JobID
                        WHERE ScheduledDate = @ScheduledDate;",
                        connection))
                    {
                        slotCheckSql.Parameters.AddWithValue(
                            "@ScheduledDate",
                            currentDate.ToString("yyyy-MM-dd")
                        );

                        using (var reader = slotCheckSql.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int timeSlot = reader.GetInt32(0);
                                existingRegion = reader.GetString(1);

                                if (timeSlot == 1)
                                {
                                    amSlotTaken = true;
                                }
                                else
                                {
                                    pmSlotTaken = true;
                                }
                            }
                        }
                    }

                    if (amSlotTaken && pmSlotTaken)
                    {
                        continue;
                    }

                    if (existingRegion != null &&
                        !string.Equals(existingRegion, jobRegion, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    availableDates.Add(new AvailableDate
                    {
                        Date = currentDate.ToString("yyyy-MM-dd"),
                        AmAvailable = !amSlotTaken,
                        PmAvailable = !pmSlotTaken
                    });

                    if (availableDates.Count >= maxResults)
                    {
                        break;
                    }
                }
            }

            return availableDates;
        }

        private string GetJobRegion(
            SQLiteConnection connection,
            string jobId)
        {
            using (var regionSql = new SQLiteCommand(
                "SELECT Location FROM Jobs WHERE JobID = @JobID;",
                connection))
            {
                regionSql.Parameters.AddWithValue(
                    "@JobID",
                    jobId
                );

                return regionSql.ExecuteScalar()?.ToString()
                    ?? "Unknown";
            }
        }
    }

    public class AvailableDate
    {
        public string? Date { get; set; }
        public bool AmAvailable { get; set; }
        public bool PmAvailable { get; set; }
    }
}
