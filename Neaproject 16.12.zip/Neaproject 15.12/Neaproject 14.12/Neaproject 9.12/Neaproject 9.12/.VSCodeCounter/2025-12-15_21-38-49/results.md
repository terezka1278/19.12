# Summary

Date : 2025-12-15 21:38:49

Directory c:\\Users\\terez\\Desktop\\CODE\\Neaproject 15.12\\Neaproject 14.12\\Neaproject 9.12\\Neaproject 9.12

Total : 88 files,  7010 codes, 304 comments, 948 blanks, all 8262 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 21 | 1,984 | 0 | 5 | 1,989 |
| C# | 31 | 1,569 | 122 | 262 | 1,953 |
| JavaScript | 13 | 1,328 | 137 | 348 | 1,813 |
| HTML | 15 | 1,163 | 33 | 132 | 1,328 |
| PostCSS | 4 | 911 | 12 | 195 | 1,118 |
| XML | 3 | 34 | 0 | 5 | 39 |
| Properties | 1 | 21 | 0 | 1 | 22 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 88 | 7,010 | 304 | 948 | 8,262 |
| Neaproject | 88 | 7,010 | 304 | 948 | 8,262 |
| Neaproject\\.vs | 2 | 1,102 | 0 | 0 | 1,102 |
| Neaproject\\.vs\\Neaproject | 2 | 1,102 | 0 | 0 | 1,102 |
| Neaproject\\.vs\\Neaproject\\v17 | 2 | 1,102 | 0 | 0 | 1,102 |
| Neaproject\\Neaproject | 86 | 5,908 | 304 | 948 | 7,160 |
| Neaproject\\Neaproject (Files) | 4 | 46 | 0 | 13 | 59 |
| Neaproject\\Neaproject\\Controllers | 6 | 570 | 43 | 114 | 727 |
| Neaproject\\Neaproject\\Data | 6 | 513 | 57 | 83 | 653 |
| Neaproject\\Neaproject\\DataObjects | 8 | 126 | 2 | 18 | 146 |
| Neaproject\\Neaproject\\Methods | 4 | 274 | 8 | 30 | 312 |
| Neaproject\\Neaproject\\Models | 3 | 45 | 0 | 4 | 49 |
| Neaproject\\Neaproject\\Properties | 1 | 38 | 0 | 1 | 39 |
| Neaproject\\Neaproject\\bin | 6 | 129 | 0 | 2 | 131 |
| Neaproject\\Neaproject\\bin\\Debug | 6 | 129 | 0 | 2 | 131 |
| Neaproject\\Neaproject\\bin\\Debug\\net8.0 | 6 | 129 | 0 | 2 | 131 |
| Neaproject\\Neaproject\\obj | 16 | 765 | 12 | 8 | 785 |
| Neaproject\\Neaproject\\obj (Files) | 4 | 304 | 0 | 0 | 304 |
| Neaproject\\Neaproject\\obj\\Debug | 12 | 461 | 12 | 8 | 481 |
| Neaproject\\Neaproject\\obj\\Debug\\net8.0 | 12 | 461 | 12 | 8 | 481 |
| Neaproject\\Neaproject\\wwwroot | 32 | 3,402 | 182 | 675 | 4,259 |
| Neaproject\\Neaproject\\wwwroot\\css | 19 | 2,074 | 45 | 327 | 2,446 |
| Neaproject\\Neaproject\\wwwroot\\js | 13 | 1,328 | 137 | 348 | 1,813 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)