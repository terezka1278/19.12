# Details

Date : 2025-12-15 21:38:49

Directory c:\\Users\\terez\\Desktop\\CODE\\Neaproject 15.12\\Neaproject 14.12\\Neaproject 9.12\\Neaproject 9.12

Total : 88 files,  7010 codes, 304 comments, 948 blanks, all 8262 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Neaproject/.vs/Neaproject/v17/DocumentLayout.backup.json](/Neaproject/.vs/Neaproject/v17/DocumentLayout.backup.json) | JSON | 551 | 0 | 0 | 551 |
| [Neaproject/.vs/Neaproject/v17/DocumentLayout.json](/Neaproject/.vs/Neaproject/v17/DocumentLayout.json) | JSON | 551 | 0 | 0 | 551 |
| [Neaproject/Neaproject/Controllers/BookingController.cs](/Neaproject/Neaproject/Controllers/BookingController.cs) | C# | 191 | 20 | 34 | 245 |
| [Neaproject/Neaproject/Controllers/BusinessDocumentsController.cs](/Neaproject/Neaproject/Controllers/BusinessDocumentsController.cs) | C# | 111 | 13 | 25 | 149 |
| [Neaproject/Neaproject/Controllers/BusinessJobController.cs](/Neaproject/Neaproject/Controllers/BusinessJobController.cs) | C# | 29 | 2 | 5 | 36 |
| [Neaproject/Neaproject/Controllers/ClientAccountController.cs](/Neaproject/Neaproject/Controllers/ClientAccountController.cs) | C# | 53 | 0 | 9 | 62 |
| [Neaproject/Neaproject/Controllers/ClientBookingController.cs](/Neaproject/Neaproject/Controllers/ClientBookingController.cs) | C# | 104 | 7 | 27 | 138 |
| [Neaproject/Neaproject/Controllers/ClientController.cs](/Neaproject/Neaproject/Controllers/ClientController.cs) | C# | 82 | 1 | 14 | 97 |
| [Neaproject/Neaproject/DataObjects/BookingStep1Request.cs](/Neaproject/Neaproject/DataObjects/BookingStep1Request.cs) | C# | 13 | 0 | 0 | 13 |
| [Neaproject/Neaproject/DataObjects/BookingStep2Request.cs](/Neaproject/Neaproject/DataObjects/BookingStep2Request.cs) | C# | 16 | 0 | 5 | 21 |
| [Neaproject/Neaproject/DataObjects/ClientBooking.cs](/Neaproject/Neaproject/DataObjects/ClientBooking.cs) | C# | 39 | 0 | 5 | 44 |
| [Neaproject/Neaproject/DataObjects/ClientCreateRequest.cs](/Neaproject/Neaproject/DataObjects/ClientCreateRequest.cs) | C# | 13 | 0 | 1 | 14 |
| [Neaproject/Neaproject/DataObjects/ClientUpdate.cs](/Neaproject/Neaproject/DataObjects/ClientUpdate.cs) | C# | 11 | 0 | 1 | 12 |
| [Neaproject/Neaproject/DataObjects/InvoiceCreateRequest.cs](/Neaproject/Neaproject/DataObjects/InvoiceCreateRequest.cs) | C# | 15 | 2 | 4 | 21 |
| [Neaproject/Neaproject/DataObjects/LoginRequest.cs](/Neaproject/Neaproject/DataObjects/LoginRequest.cs) | C# | 8 | 0 | 1 | 9 |
| [Neaproject/Neaproject/DataObjects/QuoteCreateRequest.cs](/Neaproject/Neaproject/DataObjects/QuoteCreateRequest.cs) | C# | 11 | 0 | 1 | 12 |
| [Neaproject/Neaproject/Data/BookingDataAccess.cs](/Neaproject/Neaproject/Data/BookingDataAccess.cs) | C# | 136 | 9 | 23 | 168 |
| [Neaproject/Neaproject/Data/ClientDataAccess.cs](/Neaproject/Neaproject/Data/ClientDataAccess.cs) | C# | 94 | 0 | 15 | 109 |
| [Neaproject/Neaproject/Data/InvoiceDataAccess.cs](/Neaproject/Neaproject/Data/InvoiceDataAccess.cs) | C# | 93 | 15 | 13 | 121 |
| [Neaproject/Neaproject/Data/QuoteDataAccess.cs](/Neaproject/Neaproject/Data/QuoteDataAccess.cs) | C# | 116 | 18 | 15 | 149 |
| [Neaproject/Neaproject/Data/ServicesDataAccess.cs](/Neaproject/Neaproject/Data/ServicesDataAccess.cs) | C# | 62 | 15 | 15 | 92 |
| [Neaproject/Neaproject/Data/SqliteDataAccess.cs](/Neaproject/Neaproject/Data/SqliteDataAccess.cs) | C# | 12 | 0 | 2 | 14 |
| [Neaproject/Neaproject/Methods/ClientIdGenerator.cs](/Neaproject/Neaproject/Methods/ClientIdGenerator.cs) | C# | 17 | 0 | 2 | 19 |
| [Neaproject/Neaproject/Methods/FindAvailableSlots.cs](/Neaproject/Neaproject/Methods/FindAvailableSlots.cs) | C# | 81 | 8 | 19 | 108 |
| [Neaproject/Neaproject/Methods/LocationFinder.cs](/Neaproject/Neaproject/Methods/LocationFinder.cs) | C# | 148 | 0 | 6 | 154 |
| [Neaproject/Neaproject/Methods/PasswordHasher.cs](/Neaproject/Neaproject/Methods/PasswordHasher.cs) | C# | 28 | 0 | 3 | 31 |
| [Neaproject/Neaproject/Models/Client.cs](/Neaproject/Neaproject/Models/Client.cs) | C# | 15 | 0 | 1 | 16 |
| [Neaproject/Neaproject/Models/Job.cs](/Neaproject/Neaproject/Models/Job.cs) | C# | 13 | 0 | 1 | 14 |
| [Neaproject/Neaproject/Models/User.cs](/Neaproject/Neaproject/Models/User.cs) | C# | 17 | 0 | 2 | 19 |
| [Neaproject/Neaproject/Neaproject.csproj](/Neaproject/Neaproject/Neaproject.csproj) | XML | 16 | 0 | 5 | 21 |
| [Neaproject/Neaproject/Program.cs](/Neaproject/Neaproject/Program.cs) | C# | 13 | 0 | 6 | 19 |
| [Neaproject/Neaproject/Properties/launchSettings.json](/Neaproject/Neaproject/Properties/launchSettings.json) | JSON | 38 | 0 | 1 | 39 |
| [Neaproject/Neaproject/appsettings.Development.json](/Neaproject/Neaproject/appsettings.Development.json) | JSON | 8 | 0 | 1 | 9 |
| [Neaproject/Neaproject/appsettings.json](/Neaproject/Neaproject/appsettings.json) | JSON | 9 | 0 | 1 | 10 |
| [Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.deps.json](/Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.deps.json) | JSON | 91 | 0 | 0 | 91 |
| [Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.runtimeconfig.json](/Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.runtimeconfig.json) | JSON | 19 | 0 | 0 | 19 |
| [Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.staticwebassets.endpoints.json](/Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.staticwebassets.endpoints.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.staticwebassets.runtime.json](/Neaproject/Neaproject/bin/Debug/net8.0/Neaproject.staticwebassets.runtime.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/bin/Debug/net8.0/appsettings.Development.json](/Neaproject/Neaproject/bin/Debug/net8.0/appsettings.Development.json) | JSON | 8 | 0 | 1 | 9 |
| [Neaproject/Neaproject/bin/Debug/net8.0/appsettings.json](/Neaproject/Neaproject/bin/Debug/net8.0/appsettings.json) | JSON | 9 | 0 | 1 | 10 |
| [Neaproject/Neaproject/obj/Debug/net8.0/.NETCoreApp,Version=v8.0.AssemblyAttributes.cs](/Neaproject/Neaproject/obj/Debug/net8.0/.NETCoreApp,Version=v8.0.AssemblyAttributes.cs) | C# | 3 | 1 | 1 | 5 |
| [Neaproject/Neaproject/obj/Debug/net8.0/ApiEndpoints.json](/Neaproject/Neaproject/obj/Debug/net8.0/ApiEndpoints.json) | JSON | 405 | 0 | 0 | 405 |
| [Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.AssemblyInfo.cs](/Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.AssemblyInfo.cs) | C# | 9 | 10 | 5 | 24 |
| [Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.GeneratedMSBuildEditorConfig.editorconfig](/Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.GeneratedMSBuildEditorConfig.editorconfig) | Properties | 21 | 0 | 1 | 22 |
| [Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.GlobalUsings.g.cs](/Neaproject/Neaproject/obj/Debug/net8.0/Neaproject.GlobalUsings.g.cs) | C# | 16 | 1 | 1 | 18 |
| [Neaproject/Neaproject/obj/Debug/net8.0/rjimswa.dswa.cache.json](/Neaproject/Neaproject/obj/Debug/net8.0/rjimswa.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/rjsmcshtml.dswa.cache.json](/Neaproject/Neaproject/obj/Debug/net8.0/rjsmcshtml.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/rjsmrazor.dswa.cache.json](/Neaproject/Neaproject/obj/Debug/net8.0/rjsmrazor.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/rpswa.dswa.cache.json](/Neaproject/Neaproject/obj/Debug/net8.0/rpswa.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.build.endpoints.json](/Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.build.endpoints.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.build.json](/Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.build.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.development.json](/Neaproject/Neaproject/obj/Debug/net8.0/staticwebassets.development.json) | JSON | 1 | 0 | 0 | 1 |
| [Neaproject/Neaproject/obj/Neaproject.csproj.nuget.dgspec.json](/Neaproject/Neaproject/obj/Neaproject.csproj.nuget.dgspec.json) | JSON | 87 | 0 | 0 | 87 |
| [Neaproject/Neaproject/obj/Neaproject.csproj.nuget.g.props](/Neaproject/Neaproject/obj/Neaproject.csproj.nuget.g.props) | XML | 16 | 0 | 0 | 16 |
| [Neaproject/Neaproject/obj/Neaproject.csproj.nuget.g.targets](/Neaproject/Neaproject/obj/Neaproject.csproj.nuget.g.targets) | XML | 2 | 0 | 0 | 2 |
| [Neaproject/Neaproject/obj/project.assets.json](/Neaproject/Neaproject/obj/project.assets.json) | JSON | 199 | 0 | 0 | 199 |
| [Neaproject/Neaproject/wwwroot/css/booking.html](/Neaproject/Neaproject/wwwroot/css/booking.html) | HTML | 117 | 3 | 13 | 133 |
| [Neaproject/Neaproject/wwwroot/css/business-documents.html](/Neaproject/Neaproject/wwwroot/css/business-documents.html) | HTML | 63 | 0 | 3 | 66 |
| [Neaproject/Neaproject/wwwroot/css/business-home.html](/Neaproject/Neaproject/wwwroot/css/business-home.html) | HTML | 82 | 3 | 4 | 89 |
| [Neaproject/Neaproject/wwwroot/css/business-invoice.html](/Neaproject/Neaproject/wwwroot/css/business-invoice.html) | HTML | 67 | 6 | 15 | 88 |
| [Neaproject/Neaproject/wwwroot/css/business-quote.html](/Neaproject/Neaproject/wwwroot/css/business-quote.html) | HTML | 76 | 5 | 15 | 96 |
| [Neaproject/Neaproject/wwwroot/css/business-styles.css](/Neaproject/Neaproject/wwwroot/css/business-styles.css) | PostCSS | 230 | 2 | 54 | 286 |
| [Neaproject/Neaproject/wwwroot/css/client-account.html](/Neaproject/Neaproject/wwwroot/css/client-account.html) | HTML | 106 | 0 | 13 | 119 |
| [Neaproject/Neaproject/wwwroot/css/client-booking.html](/Neaproject/Neaproject/wwwroot/css/client-booking.html) | HTML | 109 | 2 | 8 | 119 |
| [Neaproject/Neaproject/wwwroot/css/client-documents.html](/Neaproject/Neaproject/wwwroot/css/client-documents.html) | HTML | 55 | 0 | 5 | 60 |
| [Neaproject/Neaproject/wwwroot/css/client-home.html](/Neaproject/Neaproject/wwwroot/css/client-home.html) | HTML | 83 | 1 | 14 | 98 |
| [Neaproject/Neaproject/wwwroot/css/client-styles.css](/Neaproject/Neaproject/wwwroot/css/client-styles.css) | PostCSS | 203 | 2 | 44 | 249 |
| [Neaproject/Neaproject/wwwroot/css/contact.html](/Neaproject/Neaproject/wwwroot/css/contact.html) | HTML | 66 | 1 | 10 | 77 |
| [Neaproject/Neaproject/wwwroot/css/create-account.html](/Neaproject/Neaproject/wwwroot/css/create-account.html) | HTML | 65 | 1 | 9 | 75 |
| [Neaproject/Neaproject/wwwroot/css/faqs.html](/Neaproject/Neaproject/wwwroot/css/faqs.html) | HTML | 65 | 0 | 7 | 72 |
| [Neaproject/Neaproject/wwwroot/css/index.html](/Neaproject/Neaproject/wwwroot/css/index.html) | HTML | 100 | 4 | 6 | 110 |
| [Neaproject/Neaproject/wwwroot/css/login.html](/Neaproject/Neaproject/wwwroot/css/login.html) | HTML | 38 | 1 | 7 | 46 |
| [Neaproject/Neaproject/wwwroot/css/services.html](/Neaproject/Neaproject/wwwroot/css/services.html) | HTML | 71 | 6 | 3 | 80 |
| [Neaproject/Neaproject/wwwroot/css/stylelogins.css](/Neaproject/Neaproject/wwwroot/css/stylelogins.css) | PostCSS | 180 | 1 | 32 | 213 |
| [Neaproject/Neaproject/wwwroot/css/styles.css](/Neaproject/Neaproject/wwwroot/css/styles.css) | PostCSS | 298 | 7 | 65 | 370 |
| [Neaproject/Neaproject/wwwroot/js/booking.js](/Neaproject/Neaproject/wwwroot/js/booking.js) | JavaScript | 225 | 15 | 57 | 297 |
| [Neaproject/Neaproject/wwwroot/js/business-documents.js](/Neaproject/Neaproject/wwwroot/js/business-documents.js) | JavaScript | 161 | 22 | 49 | 232 |
| [Neaproject/Neaproject/wwwroot/js/business-home.js](/Neaproject/Neaproject/wwwroot/js/business-home.js) | JavaScript | 232 | 28 | 55 | 315 |
| [Neaproject/Neaproject/wwwroot/js/business-invoice.js](/Neaproject/Neaproject/wwwroot/js/business-invoice.js) | JavaScript | 95 | 9 | 25 | 129 |
| [Neaproject/Neaproject/wwwroot/js/business-jobs.js](/Neaproject/Neaproject/wwwroot/js/business-jobs.js) | JavaScript | 79 | 1 | 16 | 96 |
| [Neaproject/Neaproject/wwwroot/js/business-quote.js](/Neaproject/Neaproject/wwwroot/js/business-quote.js) | JavaScript | 67 | 14 | 18 | 99 |
| [Neaproject/Neaproject/wwwroot/js/client-account.js](/Neaproject/Neaproject/wwwroot/js/client-account.js) | JavaScript | 50 | 3 | 10 | 63 |
| [Neaproject/Neaproject/wwwroot/js/client-documents.js](/Neaproject/Neaproject/wwwroot/js/client-documents.js) | JavaScript | 165 | 28 | 51 | 244 |
| [Neaproject/Neaproject/wwwroot/js/client-home.js](/Neaproject/Neaproject/wwwroot/js/client-home.js) | JavaScript | 115 | 8 | 29 | 152 |
| [Neaproject/Neaproject/wwwroot/js/create-account.js](/Neaproject/Neaproject/wwwroot/js/create-account.js) | JavaScript | 51 | 5 | 14 | 70 |
| [Neaproject/Neaproject/wwwroot/js/login.js](/Neaproject/Neaproject/wwwroot/js/login.js) | JavaScript | 48 | 2 | 13 | 63 |
| [Neaproject/Neaproject/wwwroot/js/logout.js](/Neaproject/Neaproject/wwwroot/js/logout.js) | JavaScript | 16 | 1 | 4 | 21 |
| [Neaproject/Neaproject/wwwroot/js/scripts.js](/Neaproject/Neaproject/wwwroot/js/scripts.js) | JavaScript | 24 | 1 | 7 | 32 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)