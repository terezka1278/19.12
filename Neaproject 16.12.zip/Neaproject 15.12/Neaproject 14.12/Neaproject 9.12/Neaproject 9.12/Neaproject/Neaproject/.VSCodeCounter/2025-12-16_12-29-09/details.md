# Details

Date : 2025-12-16 12:29:09

Directory c:\\Users\\terez\\Desktop\\CODE\\Neaproject 15.12\\Neaproject 14.12\\Neaproject 9.12\\Neaproject 9.12\\Neaproject\\Neaproject

Total : 87 files,  5951 codes, 287 comments, 957 blanks, all 7195 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Controllers/BookingController.cs](/Controllers/BookingController.cs) | C# | 191 | 20 | 34 | 245 |
| [Controllers/BusinessDocumentsController.cs](/Controllers/BusinessDocumentsController.cs) | C# | 111 | 13 | 25 | 149 |
| [Controllers/BusinessJobController.cs](/Controllers/BusinessJobController.cs) | C# | 29 | 2 | 5 | 36 |
| [Controllers/ClientAccountController.cs](/Controllers/ClientAccountController.cs) | C# | 53 | 0 | 9 | 62 |
| [Controllers/ClientBookingController.cs](/Controllers/ClientBookingController.cs) | C# | 107 | 4 | 31 | 142 |
| [Controllers/ClientController.cs](/Controllers/ClientController.cs) | C# | 82 | 1 | 14 | 97 |
| [DataObjects/BookingStep1Request.cs](/DataObjects/BookingStep1Request.cs) | C# | 13 | 0 | 0 | 13 |
| [DataObjects/BookingStep2Request.cs](/DataObjects/BookingStep2Request.cs) | C# | 16 | 0 | 5 | 21 |
| [DataObjects/ClientBooking.cs](/DataObjects/ClientBooking.cs) | C# | 39 | 0 | 5 | 44 |
| [DataObjects/ClientCreateRequest.cs](/DataObjects/ClientCreateRequest.cs) | C# | 13 | 0 | 1 | 14 |
| [DataObjects/ClientUpdate.cs](/DataObjects/ClientUpdate.cs) | C# | 11 | 0 | 1 | 12 |
| [DataObjects/InvoiceCreateRequest.cs](/DataObjects/InvoiceCreateRequest.cs) | C# | 15 | 2 | 4 | 21 |
| [DataObjects/LoginRequest.cs](/DataObjects/LoginRequest.cs) | C# | 8 | 0 | 1 | 9 |
| [DataObjects/QuoteCreateRequest.cs](/DataObjects/QuoteCreateRequest.cs) | C# | 11 | 0 | 1 | 12 |
| [Data/BookingDataAccess.cs](/Data/BookingDataAccess.cs) | C# | 136 | 9 | 23 | 168 |
| [Data/ClientDataAccess.cs](/Data/ClientDataAccess.cs) | C# | 107 | 0 | 18 | 125 |
| [Data/InvoiceDataAccess.cs](/Data/InvoiceDataAccess.cs) | C# | 93 | 15 | 13 | 121 |
| [Data/QuoteDataAccess.cs](/Data/QuoteDataAccess.cs) | C# | 116 | 18 | 15 | 149 |
| [Data/ServicesDataAccess.cs](/Data/ServicesDataAccess.cs) | C# | 62 | 15 | 15 | 92 |
| [Data/SqliteDataAccess.cs](/Data/SqliteDataAccess.cs) | C# | 12 | 0 | 2 | 14 |
| [Methods/ClientIdGenerator.cs](/Methods/ClientIdGenerator.cs) | C# | 17 | 0 | 2 | 19 |
| [Methods/FindAvailableSlots.cs](/Methods/FindAvailableSlots.cs) | C# | 81 | 8 | 19 | 108 |
| [Methods/LocationFinder.cs](/Methods/LocationFinder.cs) | C# | 148 | 0 | 6 | 154 |
| [Methods/PasswordHasher.cs](/Methods/PasswordHasher.cs) | C# | 28 | 0 | 3 | 31 |
| [Models/Client.cs](/Models/Client.cs) | C# | 15 | 0 | 1 | 16 |
| [Models/Job.cs](/Models/Job.cs) | C# | 13 | 0 | 1 | 14 |
| [Models/User.cs](/Models/User.cs) | C# | 17 | 0 | 2 | 19 |
| [Neaproject.csproj](/Neaproject.csproj) | XML | 16 | 0 | 5 | 21 |
| [Program.cs](/Program.cs) | C# | 13 | 0 | 6 | 19 |
| [Properties/launchSettings.json](/Properties/launchSettings.json) | JSON | 38 | 0 | 1 | 39 |
| [appsettings.Development.json](/appsettings.Development.json) | JSON | 8 | 0 | 1 | 9 |
| [appsettings.json](/appsettings.json) | JSON | 9 | 0 | 1 | 10 |
| [bin/Debug/net8.0/Neaproject.deps.json](/bin/Debug/net8.0/Neaproject.deps.json) | JSON | 91 | 0 | 0 | 91 |
| [bin/Debug/net8.0/Neaproject.runtimeconfig.json](/bin/Debug/net8.0/Neaproject.runtimeconfig.json) | JSON | 19 | 0 | 0 | 19 |
| [bin/Debug/net8.0/Neaproject.staticwebassets.endpoints.json](/bin/Debug/net8.0/Neaproject.staticwebassets.endpoints.json) | JSON | 1 | 0 | 0 | 1 |
| [bin/Debug/net8.0/Neaproject.staticwebassets.runtime.json](/bin/Debug/net8.0/Neaproject.staticwebassets.runtime.json) | JSON | 1 | 0 | 0 | 1 |
| [bin/Debug/net8.0/appsettings.Development.json](/bin/Debug/net8.0/appsettings.Development.json) | JSON | 8 | 0 | 1 | 9 |
| [bin/Debug/net8.0/appsettings.json](/bin/Debug/net8.0/appsettings.json) | JSON | 9 | 0 | 1 | 10 |
| [obj/Debug/net8.0/.NETCoreApp,Version=v8.0.AssemblyAttributes.cs](/obj/Debug/net8.0/.NETCoreApp,Version=v8.0.AssemblyAttributes.cs) | C# | 3 | 1 | 1 | 5 |
| [obj/Debug/net8.0/ApiEndpoints.json](/obj/Debug/net8.0/ApiEndpoints.json) | JSON | 405 | 0 | 0 | 405 |
| [obj/Debug/net8.0/Neaproject.AssemblyInfo.cs](/obj/Debug/net8.0/Neaproject.AssemblyInfo.cs) | C# | 9 | 10 | 5 | 24 |
| [obj/Debug/net8.0/Neaproject.GeneratedMSBuildEditorConfig.editorconfig](/obj/Debug/net8.0/Neaproject.GeneratedMSBuildEditorConfig.editorconfig) | Properties | 21 | 0 | 1 | 22 |
| [obj/Debug/net8.0/Neaproject.GlobalUsings.g.cs](/obj/Debug/net8.0/Neaproject.GlobalUsings.g.cs) | C# | 16 | 1 | 1 | 18 |
| [obj/Debug/net8.0/Neaproject.sourcelink.json](/obj/Debug/net8.0/Neaproject.sourcelink.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/rjimswa.dswa.cache.json](/obj/Debug/net8.0/rjimswa.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/rjsmcshtml.dswa.cache.json](/obj/Debug/net8.0/rjsmcshtml.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/rjsmrazor.dswa.cache.json](/obj/Debug/net8.0/rjsmrazor.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/rpswa.dswa.cache.json](/obj/Debug/net8.0/rpswa.dswa.cache.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/staticwebassets.build.endpoints.json](/obj/Debug/net8.0/staticwebassets.build.endpoints.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/staticwebassets.build.json](/obj/Debug/net8.0/staticwebassets.build.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Debug/net8.0/staticwebassets.development.json](/obj/Debug/net8.0/staticwebassets.development.json) | JSON | 1 | 0 | 0 | 1 |
| [obj/Neaproject.csproj.nuget.dgspec.json](/obj/Neaproject.csproj.nuget.dgspec.json) | JSON | 87 | 0 | 0 | 87 |
| [obj/Neaproject.csproj.nuget.g.props](/obj/Neaproject.csproj.nuget.g.props) | XML | 16 | 0 | 0 | 16 |
| [obj/Neaproject.csproj.nuget.g.targets](/obj/Neaproject.csproj.nuget.g.targets) | XML | 2 | 0 | 0 | 2 |
| [obj/project.assets.json](/obj/project.assets.json) | JSON | 199 | 0 | 0 | 199 |
| [wwwroot/css/booking.html](/wwwroot/css/booking.html) | HTML | 117 | 3 | 11 | 131 |
| [wwwroot/css/business-documents.html](/wwwroot/css/business-documents.html) | HTML | 76 | 2 | 6 | 84 |
| [wwwroot/css/business-home.html](/wwwroot/css/business-home.html) | HTML | 82 | 3 | 4 | 89 |
| [wwwroot/css/business-invoice.html](/wwwroot/css/business-invoice.html) | HTML | 67 | 6 | 15 | 88 |
| [wwwroot/css/business-quote.html](/wwwroot/css/business-quote.html) | HTML | 76 | 5 | 15 | 96 |
| [wwwroot/css/business-styles.css](/wwwroot/css/business-styles.css) | PostCSS | 230 | 2 | 54 | 286 |
| [wwwroot/css/client-account.html](/wwwroot/css/client-account.html) | HTML | 106 | 0 | 13 | 119 |
| [wwwroot/css/client-booking.html](/wwwroot/css/client-booking.html) | HTML | 109 | 2 | 8 | 119 |
| [wwwroot/css/client-documents.html](/wwwroot/css/client-documents.html) | HTML | 86 | 6 | 18 | 110 |
| [wwwroot/css/client-home.html](/wwwroot/css/client-home.html) | HTML | 83 | 1 | 14 | 98 |
| [wwwroot/css/client-styles.css](/wwwroot/css/client-styles.css) | PostCSS | 203 | 2 | 44 | 249 |
| [wwwroot/css/contact.html](/wwwroot/css/contact.html) | HTML | 66 | 1 | 10 | 77 |
| [wwwroot/css/create-account.html](/wwwroot/css/create-account.html) | HTML | 65 | 1 | 9 | 75 |
| [wwwroot/css/faqs.html](/wwwroot/css/faqs.html) | HTML | 65 | 0 | 7 | 72 |
| [wwwroot/css/index.html](/wwwroot/css/index.html) | HTML | 100 | 4 | 6 | 110 |
| [wwwroot/css/login.html](/wwwroot/css/login.html) | HTML | 38 | 1 | 7 | 46 |
| [wwwroot/css/services.html](/wwwroot/css/services.html) | HTML | 71 | 6 | 3 | 80 |
| [wwwroot/css/stylelogins.css](/wwwroot/css/stylelogins.css) | PostCSS | 180 | 1 | 32 | 213 |
| [wwwroot/css/styles.css](/wwwroot/css/styles.css) | PostCSS | 298 | 7 | 65 | 370 |
| [wwwroot/js/booking.js](/wwwroot/js/booking.js) | JavaScript | 158 | 22 | 45 | 225 |
| [wwwroot/js/business-documents.js](/wwwroot/js/business-documents.js) | JavaScript | 166 | 8 | 45 | 219 |
| [wwwroot/js/business-home.js](/wwwroot/js/business-home.js) | JavaScript | 232 | 28 | 55 | 315 |
| [wwwroot/js/business-invoice.js](/wwwroot/js/business-invoice.js) | JavaScript | 95 | 9 | 25 | 129 |
| [wwwroot/js/business-jobs.js](/wwwroot/js/business-jobs.js) | JavaScript | 79 | 1 | 16 | 96 |
| [wwwroot/js/business-quote.js](/wwwroot/js/business-quote.js) | JavaScript | 67 | 14 | 18 | 99 |
| [wwwroot/js/client-account.js](/wwwroot/js/client-account.js) | JavaScript | 50 | 3 | 10 | 63 |
| [wwwroot/js/client-documents.js](/wwwroot/js/client-documents.js) | JavaScript | 209 | 13 | 55 | 277 |
| [wwwroot/js/client-home.js](/wwwroot/js/client-home.js) | JavaScript | 115 | 8 | 29 | 152 |
| [wwwroot/js/create-account.js](/wwwroot/js/create-account.js) | JavaScript | 51 | 5 | 14 | 70 |
| [wwwroot/js/login.js](/wwwroot/js/login.js) | JavaScript | 48 | 2 | 13 | 63 |
| [wwwroot/js/logout.js](/wwwroot/js/logout.js) | JavaScript | 16 | 1 | 4 | 21 |
| [wwwroot/js/scripts.js](/wwwroot/js/scripts.js) | JavaScript | 24 | 1 | 7 | 32 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)