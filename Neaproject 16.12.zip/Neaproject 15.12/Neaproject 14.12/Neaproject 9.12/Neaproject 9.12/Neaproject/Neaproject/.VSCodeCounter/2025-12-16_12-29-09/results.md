# Summary

Date : 2025-12-16 12:29:09

Directory c:\\Users\\terez\\Desktop\\CODE\\Neaproject 15.12\\Neaproject 14.12\\Neaproject 9.12\\Neaproject 9.12\\Neaproject\\Neaproject

Total : 87 files,  5951 codes, 287 comments, 957 blanks, all 7195 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 31 | 1,585 | 119 | 269 | 1,973 |
| JavaScript | 13 | 1,310 | 115 | 336 | 1,761 |
| HTML | 15 | 1,207 | 41 | 146 | 1,394 |
| PostCSS | 4 | 911 | 12 | 195 | 1,118 |
| JSON | 20 | 883 | 0 | 5 | 888 |
| XML | 3 | 34 | 0 | 5 | 39 |
| Properties | 1 | 21 | 0 | 1 | 22 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 87 | 5,951 | 287 | 957 | 7,195 |
| . (Files) | 4 | 46 | 0 | 13 | 59 |
| Controllers | 6 | 573 | 40 | 118 | 731 |
| Data | 6 | 526 | 57 | 86 | 669 |
| DataObjects | 8 | 126 | 2 | 18 | 146 |
| Methods | 4 | 274 | 8 | 30 | 312 |
| Models | 3 | 45 | 0 | 4 | 49 |
| Properties | 1 | 38 | 0 | 1 | 39 |
| bin | 6 | 129 | 0 | 2 | 131 |
| bin\\Debug | 6 | 129 | 0 | 2 | 131 |
| bin\\Debug\\net8.0 | 6 | 129 | 0 | 2 | 131 |
| obj | 17 | 766 | 12 | 8 | 786 |
| obj (Files) | 4 | 304 | 0 | 0 | 304 |
| obj\\Debug | 13 | 462 | 12 | 8 | 482 |
| obj\\Debug\\net8.0 | 13 | 462 | 12 | 8 | 482 |
| wwwroot | 32 | 3,428 | 168 | 677 | 4,273 |
| wwwroot\\css | 19 | 2,118 | 53 | 341 | 2,512 |
| wwwroot\\js | 13 | 1,310 | 115 | 336 | 1,761 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)