using Neaproject.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<SqliteDataAccess>();

builder.Services.AddScoped<BookingDataAccess>();
builder.Services.AddScoped<ClientDataAccess>();
builder.Services.AddScoped<QuoteDataAccess>();
builder.Services.AddScoped<InvoiceDataAccess>();
builder.Services.AddScoped<ServiceDataAccess>();

builder.Services.AddControllers();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

app.MapGet("/", () => Results.Redirect("/css/index.html"));

app.Run();
