﻿document.addEventListener("DOMContentLoaded", async () => {

    const jobId = localStorage.getItem("selectedJobId");

    if (!jobId) {
        alert("No booking selected.");
        return;
    }

    // ===============================
    // Load job + client details
    // ===============================
    const jobRes = await fetch(`/api/business/jobs/${jobId}`);

    if (!jobRes.ok) {
        alert("Failed to load job details.");
        return;
    }

    const job = await jobRes.json();

    document.getElementById("jobId").value = job.jobID;
    document.getElementById("clientId").value = job.clientID;
    document.getElementById("firstName").value = job.clientFirstName;
    document.getElementById("lastName").value = job.clientLastName;
    document.getElementById("email").value = job.email;
    document.getElementById("postcode").value = job.postcode;

    // ===============================
    // Load supplies from database
    // ===============================
    const suppliesRes = await fetch("/api/business/supplies");

    if (!suppliesRes.ok) {
        alert("Failed to load supplies.");
        return;
    }

    const supplies = await suppliesRes.json();
    const tbody = document.getElementById("invoiceItems");

    supplies.forEach(s => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>
                <select class="supply-select">
                    <option value="">-- Select supply --</option>
                    <option value="${s.supplyID}">
                        ${s.supplyName}
                    </option>
                </select>
            </td>
            <td>
                <input type="number"
                       min="0"
                       step="0.1"
                       value="0"
                       class="qty-input">
            </td>
        `;

        tbody.appendChild(row);
    });

    // ===============================
    // Create invoice
    // ===============================
    document
        .getElementById("createInvoiceButton")
        .addEventListener("click", async () => {

            const labourCost = Number(
                document.getElementById("labourCost").value || 0
            );

            const extraCost = Number(
                document.getElementById("extraCost").value || 0
            );

            const items = [];

            document
                .querySelectorAll("#invoiceItems tr")
                .forEach(row => {

                    const supplyId =
                        row.querySelector(".supply-select").value;

                    const qty =
                        Number(row.querySelector(".qty-input").value);

                    if (supplyId && qty > 0) {
                        items.push({
                            supplyID: supplyId,
                            quantity: qty
                        });
                    }
                });

            if (items.length === 0) {
                alert("Please add at least one supply.");
                return;
            }

            const response = await fetch(
                "/api/business/documents/invoices/create",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        jobID: jobId,
                        labourCost: labourCost,
                        extraCost: extraCost,
                        items: items
                    })
                }
            );

            if (!response.ok) {
                alert("Failed to create invoice.");
                return;
            }

            alert("Invoice created successfully.");
            window.location.href = "business-documents.html";
        });
});
