﻿document.addEventListener("DOMContentLoaded", async () => {

    const jobId = localStorage.getItem("selectedJobId");
    if (!jobId) {
        alert("No booking selected.");
        return;
    }

    // ============================
    // Load job + client details
    // ============================
    const jobRes = await fetch(`/api/business/jobs/${encodeURIComponent(jobId)}`);
    if (!jobRes.ok) {
        alert("Failed to load job details.");
        return;
    }

    const job = await jobRes.json();

    // Autofill fields
    document.getElementById("jobId").value = job.jobID;
    document.getElementById("clientId").value = job.clientID;
    document.getElementById("firstName").value = job.clientFirstName;
    document.getElementById("lastName").value = job.clientLastName;
    document.getElementById("phone").value = job.phoneNumber;
    document.getElementById("email").value = job.email;
    document.getElementById("postcode").value = job.postcode;
    document.getElementById("serviceName").value = job.serviceName;

    // Number of points (IMPORTANT)
    const points = Number(job.points || 1);
    document.getElementById("points").value = points;

    // ============================
    // Load default supplies (preview only)
    // ============================
    const supplyRes = await fetch(
        `/api/business/services/${encodeURIComponent(job.serviceID)}/supplies`
    );

    if (!supplyRes.ok) {
        alert("Failed to load service supplies.");
        return;
    }

    const supplies = await supplyRes.json();
    const tableBody = document.getElementById("suppliesTable");
    tableBody.innerHTML = "";

    supplies.forEach(s => {
        // 🔑 multiply base quantity by points
        const estQty = Number(s.baseQuantity) * points;

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${s.supplyName}</td>
            <td>${s.supplyID}</td>
            <td>${estQty}</td>
        `;
        tableBody.appendChild(row);
    });

    // ============================
    // Create quote (backend only)
    // ============================
    document
        .getElementById("createQuoteButton")
        .addEventListener("click", async () => {

            const res = await fetch(
                "/api/business/documents/quotes/create",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(jobId)
                }
            );

            const data = await res.json();

            if (!res.ok) {
                alert(data.message || "Failed to create quote.");
                return;
            }

            // Display calculated price from backend
            document.getElementById("quoteTotal").textContent =
                "£" + Number(data.total).toFixed(2);

            // Display calculated duration (optional)
            if (data.estDurationMins != null) {
                document.getElementById("timeEst").value =
                    data.estDurationMins + " mins";
            }

            alert("Quote created successfully.");
        });
});
