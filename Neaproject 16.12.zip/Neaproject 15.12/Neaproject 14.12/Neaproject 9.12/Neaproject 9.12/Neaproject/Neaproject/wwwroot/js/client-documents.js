﻿// ===============================
// Client Documents (Bookings)
// ===============================

let selectedJobId = null;
let selectedQuoteId = null;

document.addEventListener("DOMContentLoaded", () => {

    const clientId = localStorage.getItem("clientID");
    if (!clientId) {
        window.location.href = "login.html";
        return;
    }

    const manageOutput = document.getElementById("manage-output");
    const quotesOutput = document.getElementById("quotes-list");
    const invoicesOutput = document.getElementById("invoices-list");

    const cancelButton = document.getElementById("cancelButton");
    const acceptButton = document.getElementById("acceptQuoteButton");
    const declineButton = document.getElementById("declineQuoteButton");

    loadClientBookings(clientId, manageOutput);
    loadClientQuotes(clientId, quotesOutput);
    loadClientInvoices(clientId, invoicesOutput);

    // ================= CANCEL BOOKING (CLIENT) =================
    if (cancelButton) {
        cancelButton.addEventListener("click", async () => {

            if (!selectedJobId) {
                alert("Please select a booking first.");
                return;
            }

            if (!confirm("Are you sure you want to cancel this booking?")) return;

            const res = await fetch(`/api/client-bookings/${selectedJobId}`, {
                method: "DELETE"
            });

            if (!res.ok) {
                alert("Failed to cancel booking.");
                return;
            }

            // -------- SEND EMAILS --------
            const clientEmail = localStorage.getItem("clientEmail");
            const businessEmail = "business.project@gmail.com";

            // Client email
            const clientForm = document.getElementById("cancelClientEmail");
            clientForm.action = "https://formsubmit.co/" + clientEmail;
            clientForm.submit();

            // Business email
            document.getElementById("cancelJobId").value = selectedJobId;
            const businessForm = document.getElementById("cancelBusinessEmail");
            businessForm.action = "https://formsubmit.co/" + businessEmail;
            businessForm.submit();

            alert("Booking cancelled.");
            location.reload();
        });
    }

    
    // ================= ACCEPT QUOTE =================
    if (acceptButton) {
        acceptButton.addEventListener("click", async () => {

            if (!selectedQuoteId || !selectedJobId) {
                alert("Select a quote first.");
                return;
            }

            const res = await fetch(`/api/client-bookings/quotes/${selectedQuoteId}/accept`, {

                method: "POST"
            });

            if (!res.ok) {
                alert("Failed to accept quote.");
                return;
            }

            // -------- SEND EMAIL TO BUSINESS --------
            const businessEmail = "business.project@gmail.com";

            document.getElementById("acceptedQuoteJobId").value = selectedJobId;
            document.getElementById("acceptedQuoteId").value = selectedQuoteId;

            const emailForm = document.getElementById("quoteAcceptedEmail");
            emailForm.action = "https://formsubmit.co/" + businessEmail;
            emailForm.submit();

            alert("Quote accepted.");
            location.reload();
        });
    }

    

    // ================= DECLINE QUOTE =================
    if (declineButton) {
        declineButton.addEventListener("click", async () => {

            if (!selectedQuoteId) {
                alert("Select a quote first.");
                return;
            }

            await fetch(`/api/client-bookings/quotes/${selectedQuoteId}/decline`, {
                method: "POST"
            });

            alert("Quote declined.");
            location.reload();
        });
    }
});


// ================= LOAD BOOKINGS =================
async function loadClientBookings(clientId, container) {

    container.textContent = "Loading bookings...";

    const res = await fetch(`/api/client-bookings/${clientId}`);
    if (!res.ok) {
        container.textContent = "Failed to load bookings.";
        return;
    }

    const bookings = await res.json();

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${bookings.map(b => `
                    <tr class="booking-row"
                        onclick="selectBooking('${b.jobID}', this)">
                        <td>${b.jobID}</td>
                        <td>${b.serviceName}</td>
                        <td>${b.status}</td>
                    </tr>
                `).join("")}
            </tbody>
        </table>
    `;
}

function selectBooking(jobId, row) {
    selectedJobId = jobId;
    document.querySelectorAll(".booking-row")
        .forEach(r => r.classList.remove("selected"));
    row.classList.add("selected");
}


// ================= LOAD QUOTES =================
async function loadClientQuotes(clientId, container) {

    container.textContent = "Loading quotes...";

    const res = await fetch(`/api/client-bookings/${clientId}/quotes`);
    if (!res.ok) {
        container.textContent = "Failed to load quotes.";
        return;
    }

    const quotes = await res.json();

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Quote ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Price</th>
                    <th>Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${quotes.map(q => {
        let statusText = "Pending";
        if (q.accepted === 1) statusText = "Accepted";
        if (q.accepted === 0) statusText = "Declined";

        return `
                        <tr onclick="selectQuote('${q.quoteID}', '${q.jobID}', ${q.accepted})">
                            <td>${q.quoteID}</td>
                            <td>${q.jobID}</td>
                            <td>${q.serviceName}</td>
                            <td>£${q.estPrice.toFixed(2)}</td>
                            <td>${q.estDuration} hrs</td>
                            <td>${statusText}</td>
                        </tr>
                    `;
    }).join("")}
            </tbody>
        </table>
    `;
}

function selectQuote(quoteId, jobId, accepted) {

    selectedQuoteId = quoteId;
    selectedJobId = jobId;

    const statusDiv = document.getElementById("quoteStatus");
    const actionsDiv = document.getElementById("quoteActions");

    if (accepted === 1) {
        statusDiv.textContent = "Status: Accepted. The business will proceed.";
        actionsDiv.style.display = "none";
    }
    else if (accepted === 0) {
        statusDiv.textContent = "Status: Declined. You declined this quote.";
        actionsDiv.style.display = "none";
    }
    else {
        statusDiv.textContent = "Status: Awaiting your decision.";
        actionsDiv.style.display = "block";
    }
}


// ================= LOAD INVOICES =================
async function loadClientInvoices(clientId, container) {

    container.textContent = "Loading invoices...";

    const res = await fetch(`/api/client-bookings/${clientId}/invoices`);
    if (!res.ok) {
        container.textContent = "Failed to load invoices.";
        return;
    }

    const invoices = await res.json();

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${invoices.map(i => `
                    <tr>
                        <td>${i.invoiceID}</td>
                        <td>${i.jobID}</td>
                        <td>${i.serviceName}</td>
                        <td>£${i.finalPrice.toFixed(2)}</td>
                        <td>${i.paymentStatus}</td>
                    </tr>
                `).join("")}
            </tbody>
        </table>
    `;
}
