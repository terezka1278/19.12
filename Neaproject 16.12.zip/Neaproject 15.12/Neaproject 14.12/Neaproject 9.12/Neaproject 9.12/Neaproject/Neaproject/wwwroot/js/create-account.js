﻿document.addEventListener("DOMContentLoaded", () => { //run only when HTML is fully loaded
    console.log("create-account.js loaded"); //debugging log

    //get elements
    const form = document.getElementById("create-account-form");  //get account form
    const output = document.getElementById("create-output"); //get output element
    const popup = document.getElementById("nextPopup"); // get popup element

    if (!form) { //if there is no form
        console.log("Create account form not found"); //debugging log
        return; //stop
    }

    form.addEventListener("submit", async (e) => { // when create account button clicked
        e.preventDefault(); //do not submit form normally

        //get elements
        const password = document.getElementById("password").value; //get password
        const confirm = document.getElementById("confirm").value; //get re-entered password

        if (password !== confirm) { //if passwords do not match
            if (output) output.textContent = "Passwords do not match."; //output error message
            return; //stop
        }

        //create JSON object with form data
        const body = {
            firstName: document.getElementById("firstname").value.trim(), //get first name
            lastName: document.getElementById("lastname").value.trim(), //get last name
            email: document.getElementById("email").value.trim(), //get email
            phoneNum: document.getElementById("phoneNum").value.trim(), //get phone number
            address: document.getElementById("address").value.trim(), //get address
            postcode: document.getElementById("postcode").value.trim(), //get postcode
            password: password
        };

        console.log("Sending create-account request", body); //debugging log
        if (output) output.textContent = "Creating account..."; //output message to user

        //send POST request to backend API
        const response = await fetch("/api/client/create-account", {
            method: "POST",
            headers: { "Content-Type": "application/json" }, //tells backend it is a JSON
            body: JSON.stringify(body) //turn JS object into JSON string
        });

        const data = await response.json();//get JSON data from response
        console.log("Create-account response", response.status, data); //debugging log

        if (!response.ok) { //if response not OK (400-500 error code)
            if (output) output.textContent = data.message || "Error creating account."; //ourtput error message
            return; //stop
        }

        if (output) {
            output.textContent = "Account created! Your ID is: " + data.clientId; //output message with clientID
        }

        // store login state so user stays logged in
        localStorage.setItem("clientID", data.clientId); //store clientID
        localStorage.setItem("clientEmail", body.email); //store email

        
        if (popup) { //if popup element exists
            popup.style.display = "flex"; // show success popup
        } else { //if no popup
            window.location.href = "login.html"; //redirect to login page
        }
    });
});