﻿document.addEventListener("DOMContentLoaded", () => {

    console.log("booking.js loaded");

    const urlParams = new URLSearchParams(window.location.search);
    const isFromQuote = urlParams.get("fromQuote") === "true";

    const bookingForm = document.getElementById("booking-form");
    const nextStepButton = document.getElementById("nextButton");
    const stepOneMessage = document.getElementById("stage1-output");
    const confirmationPopup = document.getElementById("confirm-popup");
    const confirmationText = document.getElementById("confirm-popup-message");
    const closePopupButton = document.getElementById("confirm-popup-close");

    if (!bookingForm) return;

    if (isFromQuote) {
        const storedJobId = localStorage.getItem("currentJobID");

        if (!storedJobId) {
            alert("Booking session expired.");
            window.location.href = "client-documents.html";
            return;
        }

        document.getElementById("stage1").style.display = "none";
        document.querySelector(".personal").style.display = "none";
        document.querySelector(".job-info").style.display = "none";
    }

    if (!isFromQuote && nextStepButton) {
        nextStepButton.addEventListener("click", async () => {

            const firstName = document.getElementById("firstname").value.trim();
            const lastName = document.getElementById("lastname").value.trim();
            const emailAddress = document.getElementById("email").value.trim();
            const phoneNumber = document.getElementById("phoneNum").value.trim();
            const homeAddress = document.getElementById("address").value.trim();
            const postcode = document.getElementById("postcode").value.trim();
            const selectedService = document.getElementById("service").value;
            const jobSummary = document.getElementById("summary").value.trim();
            const jobPoints = Number(document.getElementById("points").value);

            if (
                !firstName || !lastName || !emailAddress || !phoneNumber ||
                !homeAddress || !postcode || !selectedService ||
                !jobSummary || !jobPoints
            ) {
                stepOneMessage.textContent = "Please fill in all required fields.";
                return;
            }

            const bookingDetails = {
                firstName,
                lastName,
                email: emailAddress,
                phoneNum: phoneNumber,
                address: homeAddress,
                postcode,
                service: selectedService,
                points: jobPoints,
                summary: jobSummary,
                clientId: localStorage.getItem("clientID") || null
            };

            stepOneMessage.textContent = "Saving your details...";

            const response = await fetch("/api/booking/step1", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(bookingDetails)
            });

            const bookingResponse = await response.json();

            if (!response.ok) {
                stepOneMessage.textContent =
                    bookingResponse.message || "Failed to create booking.";
                return;
            }

            localStorage.setItem("clientID", bookingResponse.clientId);
            localStorage.setItem("clientEmail", emailAddress);
            localStorage.setItem("clientName", `${firstName} ${lastName}`);
            localStorage.setItem("currentJobID", bookingResponse.jobId);

            stepOneMessage.textContent = "Details saved. Continue to Step 2.";
        });
    }

    bookingForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const currentJobId = localStorage.getItem("currentJobID");
        if (!currentJobId) {
            alert("Missing job information.");
            return;
        }

        const chosenDays = [];
        document.querySelectorAll(".days").forEach(box => {
            if (box.checked) chosenDays.push(box.name);
        });

        if (chosenDays.length === 0) {
            document.getElementById("date-output").textContent =
                "Please select at least one day.";
            return;
        }

        const response = await fetch("/api/booking/step2", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ jobId: currentJobId, days: chosenDays })
        });

        const availableDatesResponse = await response.json();

        if (!response.ok) {
            document.getElementById("date-output").textContent =
                "Could not find available dates.";
            return;
        }

        showAvailableDates(availableDatesResponse.suggestedDates, currentJobId);
    });

    function showAvailableDates(availableDates, jobId) {

        const outputArea = document.getElementById("date-output");
        outputArea.innerHTML = "<p>Please choose a date and time:</p>";

        availableDates.forEach(dateOption => {
            const label = document.createElement("label");

            const formattedDate = new Date(dateOption.date).toLocaleDateString(
                undefined,
                { weekday: "long", year: "numeric", month: "short", day: "numeric" }
            );

            label.innerHTML = `${formattedDate} `;

            if (dateOption.amAvailable) {
                label.innerHTML +=
                    `<input type="radio" name="slot" value="${dateOption.date}|AM"> AM `;
            } else {
                label.innerHTML += "(AM full) ";
            }

            if (dateOption.pmAvailable) {
                label.innerHTML +=
                    `<input type="radio" name="slot" value="${dateOption.date}|PM"> PM `;
            } else {
                label.innerHTML += "(PM full) ";
            }

            outputArea.appendChild(label);
            outputArea.appendChild(document.createElement("br"));
        });

        const confirmButton = document.createElement("button");
        confirmButton.type = "button";
        confirmButton.textContent = "Confirm booking";
        outputArea.appendChild(confirmButton);

        confirmButton.onclick = async () => {

            const selectedSlot = document.querySelector("input[name='slot']:checked");
            if (!selectedSlot) {
                alert("Select a date and time.");
                return;
            }

            const [chosenDate, chosenTime] = selectedSlot.value.split("|");

            const response = await fetch("/api/booking/step2/confirm", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    jobId,
                    selectedDate: chosenDate,
                    selectedSlot: chosenTime
                })
            });

            const confirmationResponse = await response.json();

            if (!response.ok) {
                alert(confirmationResponse.message || "Booking failed.");
                return;
            }

            const clientEmail = localStorage.getItem("clientEmail");

            document.getElementById("emailService").value =
                document.getElementById("service")?.selectedOptions[0]?.text || "Service";
            document.getElementById("emailDate").value = confirmationResponse.selectedDate;
            document.getElementById("emailTime").value = confirmationResponse.timeSlot;

            const emailForm = document.getElementById("bookingConfirm");
            emailForm.action = "https://formsubmit.co/" + clientEmail;
            emailForm.submit();

            const displayDate = new Date(
                confirmationResponse.selectedDate
            ).toLocaleDateString(undefined, {
                weekday: "long",
                year: "numeric",
                month: "short",
                day: "numeric"
            });

            confirmationText.textContent =
                `Your booking is confirmed for ${displayDate} (${confirmationResponse.timeSlot}).`;

            confirmationPopup.hidden = false;
        };
    }

    if (closePopupButton) {
        closePopupButton.onclick = () => confirmationPopup.hidden = true;
    }
});
