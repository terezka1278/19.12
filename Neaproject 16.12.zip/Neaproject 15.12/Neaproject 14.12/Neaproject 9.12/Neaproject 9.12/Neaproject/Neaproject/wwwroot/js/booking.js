﻿document.addEventListener("DOMContentLoaded", () => {

    console.log("booking.js loaded");

    // ===============================
    // MODE DETECTION
    // ===============================
    const params = new URLSearchParams(window.location.search);
    const fromQuote = params.get("fromQuote") === "true";

    const form = document.getElementById("booking-form");
    const nextButton = document.getElementById("nextButton");
    const stage1Output = document.getElementById("stage1-output");
    const confirmPopup = document.getElementById("confirm-popup");
    const confirmPopupMessage = document.getElementById("confirm-popup-message");
    const confirmPopupClose = document.getElementById("confirm-popup-close");

    if (!form) return;

    // ===============================
    // QUOTE → BOOKING MODE
    // ===============================
    if (fromQuote) {
        const jobId = localStorage.getItem("currentJobID");

        if (!jobId) {
            alert("Booking session expired.");
            window.location.href = "client-documents.html";
            return;
        }

        // Hide Step 1 UI
        document.getElementById("stage1").style.display = "none";
        document.querySelector(".personal").style.display = "none";
        document.querySelector(".job-info").style.display = "none";
    }

    // ===============================
    // STEP 1 — CREATE JOB (NORMAL ONLY)
    // ===============================
    if (!fromQuote && nextButton) {
        nextButton.addEventListener("click", async () => {

            const firstName = document.getElementById("firstname").value.trim();
            const lastName = document.getElementById("lastname").value.trim();
            const email = document.getElementById("email").value.trim();
            const phoneNum = document.getElementById("phoneNum").value.trim();
            const address = document.getElementById("address").value.trim();
            const postcode = document.getElementById("postcode").value.trim();
            const service = document.getElementById("service").value;
            const summary = document.getElementById("summary").value.trim();
            const points = Number(document.getElementById("points").value);

            if (!firstName || !lastName || !email || !phoneNum ||
                !address || !postcode || !service || !summary || !points) {
                stage1Output.textContent = "Please fill in all required fields.";
                return;
            }

            const body = {
                firstName,
                lastName,
                email,
                phoneNum,
                address,
                postcode,
                service,
                points,
                summary,
                clientId: localStorage.getItem("clientID") || null
            };

            stage1Output.textContent = "Saving your details...";

            const res = await fetch("/api/booking/step1", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body)
            });

            const data = await res.json();

            if (!res.ok) {
                stage1Output.textContent = data.message || "Failed to create booking.";
                return;
            }

            localStorage.setItem("clientID", data.clientId);
            localStorage.setItem("clientEmail", email);
            localStorage.setItem("clientName", `${firstName} ${lastName}`);
            localStorage.setItem("currentJobID", data.jobId);

            stage1Output.textContent = "Details saved. Continue to Step 2.";
        });
    }

    // ===============================
    // STEP 2 — FIND AVAILABLE DATES
    // ===============================
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const jobId = localStorage.getItem("currentJobID");
        if (!jobId) {
            alert("Missing job information.");
            return;
        }

        const selectedDays = [];
        document.querySelectorAll(".days").forEach(cb => {
            if (cb.checked) selectedDays.push(cb.name);
        });

        if (selectedDays.length === 0) {
            document.getElementById("date-output").textContent =
                "Please select at least one day.";
            return;
        }

        const res = await fetch("/api/booking/step2", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ jobId, days: selectedDays })
        });

        const data = await res.json();
        if (!res.ok) {
            document.getElementById("date-output").textContent =
                "Could not find available dates.";
            return;
        }

        renderSuggestedDates(data.suggestedDates, jobId);
    });

    // ===============================
    // RENDER AVAILABLE SLOTS
    // ===============================
    function renderSuggestedDates(suggestedDates, jobId) {

        const container = document.getElementById("date-output");
        container.innerHTML = "<p>Please choose a date and time:</p>";

        suggestedDates.forEach(item => {
            const label = document.createElement("label");
            const pretty = new Date(item.date).toLocaleDateString(undefined, {
                weekday: "long", year: "numeric", month: "short", day: "numeric"
            });

            label.innerHTML = `${pretty} `;

            if (item.amAvailable)
                label.innerHTML += `<input type="radio" name="slot" value="${item.date}|AM"> AM `;
            else
                label.innerHTML += "(AM full) ";

            if (item.pmAvailable)
                label.innerHTML += `<input type="radio" name="slot" value="${item.date}|PM"> PM `;
            else
                label.innerHTML += "(PM full) ";

            container.appendChild(label);
            container.appendChild(document.createElement("br"));
        });

        const confirmBtn = document.createElement("button");
        confirmBtn.type = "button";
        confirmBtn.textContent = "Confirm booking";
        container.appendChild(confirmBtn);

        confirmBtn.onclick = async () => {

            const selected = document.querySelector("input[name='slot']:checked");
            if (!selected) {
                alert("Select a date and time.");
                return;
            }

            const [selectedDate, selectedSlot] = selected.value.split("|");

            const res = await fetch("/api/booking/step2/confirm", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ jobId, selectedDate, selectedSlot })
            });

            const data = await res.json();
            if (!res.ok) {
                alert(data.message || "Booking failed.");
                return;
            }

            // ===============================
            // SEND CONFIRMATION EMAIL
            // ===============================
            const clientEmail = localStorage.getItem("clientEmail");

            document.getElementById("emailService").value =
                document.getElementById("service")?.selectedOptions[0]?.text || "Service";
            document.getElementById("emailDate").value = data.selectedDate;
            document.getElementById("emailTime").value = data.timeSlot;

            const emailForm = document.getElementById("bookingConfirm");
            emailForm.action = "https://formsubmit.co/" + clientEmail;
            emailForm.submit();

            // ===============================
            // CONFIRM POPUP
            // ===============================
            const niceDate = new Date(data.selectedDate).toLocaleDateString(undefined, {
                weekday: "long", year: "numeric", month: "short", day: "numeric"
            });

            confirmPopupMessage.textContent =
                `Your booking is confirmed for ${niceDate} (${data.timeSlot}).`;

            confirmPopup.hidden = false;
        };
    }

    if (confirmPopupClose) {
        confirmPopupClose.onclick = () => confirmPopup.hidden = true;
    }
});
