﻿using Neaproject.Data;
using System.Data.SQLite;

//Find available slots based on AM/PM availability and region checking
namespace Neaproject.Methods
{
    public class FindAvailableSlots
    {
        private readonly SqliteDataAccess _db;

        public FindAvailableSlots(SqliteDataAccess db)
        {
            _db = db;
        }

        //method to find available dates with AM/PM info
        public List<AvailableDate> FindAvailableDates(string jobId, List<DayOfWeek> selectedDays, int timeFrame, int maxResults = 5)
        {
            var today = DateTime.Today; //get today's date
            var results = new List<AvailableDate>(); //list of valid date results

            using (var conn = _db.GetConnection()) //open database connection
            {
                conn.Open();

                //get region of job being booked
                string clientRegion = GetJobRegion(conn, jobId);

                for (int i = 1; i <= timeFrame; i++)
                {
                    var date = today.AddDays(i); //next candidate date

                    if (!selectedDays.Contains(date.DayOfWeek)) //skip days not chosen
                        continue;

                    bool amTaken = false;  //track slot availability
                    bool pmTaken = false;
                    string? existingRegion = null; //region of job already booked on same day (if any)

                    //get existing bookings for this date
                    using (var cmd = new SQLiteCommand(@"
                        SELECT A.TimeSlot, J.Location
                        FROM Appointments A
                        JOIN Jobs J ON A.JobID = J.JobID
                        WHERE ScheduledDate = @d;
                    ", conn))
                    {
                        cmd.Parameters.AddWithValue("@d", date.ToString("yyyy-MM-dd"));

                        using (var r = cmd.ExecuteReader())
                        {
                            while (r.Read())
                            {
                                int slot = r.GetInt32(0);   //1=AM, 0=PM
                                existingRegion = r.GetString(1);

                                if (slot == 1) amTaken = true;
                                else pmTaken = true;
                            }
                        }
                    }

                    //if both slots full → skip the date
                    if (amTaken && pmTaken)
                        continue;

                    //if a job exists that day → must match region
                    if (existingRegion != null)
                    {
                        if (!string.Equals(existingRegion, clientRegion, StringComparison.OrdinalIgnoreCase))
                            continue;
                    }

                    //At least one slot free AND region allowed → add result
                    results.Add(new AvailableDate
                    {
                        Date = date.ToString("yyyy-MM-dd"),
                        AmAvailable = !amTaken,
                        PmAvailable = !pmTaken
                    });

                    if (results.Count >= maxResults) //limit number of results
                        break;
                }
            }

            return results; //return list of available dates
        }

        //helper method to get the region for the job being booked
        private string GetJobRegion(SQLiteConnection conn, string jobId)
        {
            using (var cmd = new SQLiteCommand("SELECT Location FROM Jobs WHERE JobID = @ID;", conn))
            {
                cmd.Parameters.AddWithValue("@ID", jobId);
                return cmd.ExecuteScalar()?.ToString() ?? "UNKNOWN";
            }
        }
    }

    public class AvailableDate
    {
        public string? Date { get; set; } // YYYY-MM-DD
        public bool AmAvailable { get; set; }
        public bool PmAvailable { get; set; }
    }
}
