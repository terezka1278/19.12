﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using Neaproject.Models;
using Neaproject.Methods;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client")]    
    public class ClientController : ControllerBase
    {
        private readonly ClientDataAccess _clients;

        public ClientController(ClientDataAccess clients)
        {
            _clients = clients;
        }


        [HttpPost("create-account")] //post request
        public IActionResult CreateAccount([FromBody] ClientCreateRequest request) 
        {
            if (request == null) // if no body sent
                return BadRequest(new { message = "No data sent." });

            var email = request.Email.Trim();
            var phone = request.PhoneNum.Trim();

            if (_clients.EmailExists(email)) //if email already in use
            {
                return BadRequest(new { message = "Email already in use." }); //output error message
            }
             
            if (_clients.PhoneExists(phone)) // if phone number already in use
            {
                return BadRequest(new { message = "Phone number already in use." }); //output error message
            }

            string id = ClientIdGenerator.CreateClientId( //make clientID
                request.FirstName,
                request.LastName,
                request.PhoneNum
            );

            var client = new Client //make client
            {
                ClientID = id,
                FirstName = request.FirstName.Trim(),
                LastName = request.LastName.Trim(),
                Email = email,
                PhoneNum = phone,
                Address = request.Address?.Trim(),
                Postcode = request.Postcode?.Trim(),
                Password = PasswordHasher.Hash(request.Password), 
                Role = "C"
            };

            try
            {
                _clients.CreateClient(client); //save to database
            }
            catch (Exception ex) { 
                return BadRequest(new { message = ex.Message }); //catch database conflicts
            }

            return Ok(new //output message
            {
                message = "Account created",
                clientId = id
            });
        }

        [HttpPost("login")] //post request
        public IActionResult Login([FromBody] LoginRequest request) 
        {
            //TODO: validation 
            var user = _clients.GetUserByEmail(request.Email.Trim()); //find user in clients table
            if (user == null) //if email not found
            {
                return BadRequest(new { message = "Account not found." }); //output message
            }
            if (!PasswordHasher.Verify(request.Password, user.Password)) //if password not matching hashed password saved
            {
                return BadRequest(new { message = "Incorrect password." }); //output error message
            }
            
            return Ok(new //ouptut message
            {
                message = "Login Successful",
                clientId = user.Id,
                role = user.Role
            });
        }
    }
}
