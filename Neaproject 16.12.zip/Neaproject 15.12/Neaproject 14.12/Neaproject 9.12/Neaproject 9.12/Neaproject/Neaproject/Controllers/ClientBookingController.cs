﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client-bookings")]
    public class ClientBookingsController : ControllerBase
    {
        private readonly BookingDataAccess _bookings;
        private readonly QuoteDataAccess _quotes;
        private readonly InvoiceDataAccess _invoice;
        private readonly ClientDataAccess _clients;

        public ClientBookingsController(
            BookingDataAccess bookings,
            QuoteDataAccess quotes,
            InvoiceDataAccess invoice,
            ClientDataAccess clients)

        {
            _bookings = bookings;
            _quotes = quotes;
            _invoice = invoice;
            _clients = clients;
        }


        [HttpGet("{clientId}")] //get all bookings
        public ActionResult<IEnumerable<ClientBooking>> GetAllBookings(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message
            var bookings = _bookings.GetBookingsForClient(clientId); //fetch al bookings for this client
            return Ok(bookings); // return booking list
        }

        [HttpGet("{clientId}/next")]  //get upcoming bookings
        public ActionResult<NextBooking> GetNextBooking(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //
                return BadRequest("ClientId is required.");
            var booking = _bookings.GetNextBookingForClient(clientId); //get next booking
            if (booking == null || !booking.HasBooking) //if no upcoming bookings
                return Ok(new NextBooking { HasBooking = false }); //output
            return Ok(booking); //return next booking
        }

        [HttpGet("{clientId}/quotes")] //get quotes for clients
        public ActionResult<IEnumerable<ClientQuote>> GetQuotes(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //if cl
                return BadRequest("ClientId is required.");

            var quotes = _quotes.GetQuotesForClient(clientId);
            return Ok(quotes);
        }

        [HttpPost("quotes/{quoteId}/accept")]
        public IActionResult AcceptQuote(string quoteId)
        {
            if (string.IsNullOrWhiteSpace(quoteId))
                return BadRequest(new { message = "Invalid quote ID." });

            try
            {
                //mark quote as accepted
                _quotes.SetQuoteAccepted(quoteId, true);

                //update job status
                _quotes.UpdateJobStatusByQuote(quoteId, "Quote Accepted");

                return Ok(new { message = "Quote accepted." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("quotes/{quoteId}/decline")]
        public IActionResult DeclineQuote(string quoteId)
        {
            if (string.IsNullOrWhiteSpace(quoteId))
                return BadRequest(new { message = "Invalid quote ID." });

            try
            {
                //mark quote as declined
                _quotes.SetQuoteAccepted(quoteId, false);

                //update job status
                _quotes.UpdateJobStatusByQuote(quoteId, "Quote Declined");

                return Ok(new { message = "Quote declined." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }



        [HttpGet("{clientId}/invoices")] //get invoices for clients
        public ActionResult<IEnumerable<ClientInvoice>> GetInvoices(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message

            var invoices = _invoice.GetInvoicesForClient(clientId); //get all invoices
            return Ok(invoices); // return invoice list
        }

        [HttpDelete("{jobId}")]
        public IActionResult CancelBooking(string jobId)
        {
            if (string.IsNullOrWhiteSpace(jobId))
                return BadRequest(new { message = "Invalid job ID." });

            var job = _bookings.GetJobById(jobId);
            if (job == null)
                return NotFound(new { message = "Job not found." });

            if (job.Status == "Completed")
                return BadRequest(new { message = "Completed jobs cannot be cancelled." });

            _bookings.DeleteAppointmentByJob(jobId);
            _bookings.DeleteQuoteByJob(jobId);
            _bookings.DeleteJob(jobId);

            return Ok(new { message = "Booking cancelled successfully." });
        }



    }


}
