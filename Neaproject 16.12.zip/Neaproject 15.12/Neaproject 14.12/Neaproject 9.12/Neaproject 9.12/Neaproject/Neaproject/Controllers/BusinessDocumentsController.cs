﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using System.Collections.Generic;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/business/documents")]
    public class BusinessDocumentsController : ControllerBase
    {
        private readonly QuoteDataAccess _quotes;
        private readonly InvoiceDataAccess _invoices;
        private readonly ServiceDataAccess _services;
        private readonly BookingDataAccess _bookings;

        public BusinessDocumentsController(
            QuoteDataAccess quotes,
            InvoiceDataAccess invoices,
            ServiceDataAccess services,
            BookingDataAccess bookings)
        {
            _quotes = quotes;
            _invoices = invoices;
            _services = services;
            _bookings = bookings;
        }

        // ===================== GET ALL QUOTES =====================
        [HttpGet("quotes")]
        public ActionResult<IEnumerable<ClientQuote>> GetAllQuotes()
        {
            var quotes = _quotes.GetAllQuotes();
            return Ok(quotes);
        }

        // ===================== CREATE QUOTE (AUTO CALCULATED) =====================
        [HttpPost("quotes/create")]
        public IActionResult CreateQuote([FromBody] string jobId)
        {
            if (string.IsNullOrWhiteSpace(jobId))
                return BadRequest(new { message = "Invalid job ID." });

            // ============================
            // Job + service info
            // ============================
            string serviceId = _services.GetServiceIdForJob(jobId);

            int points = _bookings.GetJobPoints(jobId);
            if (points <= 0) points = 1;

            decimal basePrice = _services.GetServiceBasePrice(serviceId);
            int baseDuration = _services.GetServiceBaseDuration(serviceId);

            decimal total = basePrice;
            int estDurationMins = baseDuration * points;

            string quoteId = Guid.NewGuid().ToString();

            // ============================
            // Supplies
            // ============================
            var supplies = _services.GetServiceSupplies(serviceId);

            foreach (var s in supplies)
            {
                decimal adjustedQty = s.Quantity * points;
                decimal lineCost = adjustedQty * s.UnitPrice;
                total += lineCost;

                _quotes.InsertQuoteItem(
                    Guid.NewGuid().ToString(),
                    quoteId,
                    s.SupplyID,
                    adjustedQty,
                    s.UnitPrice
                );
            }

            // ============================
            // Insert quote + update job
            // ============================
            _quotes.InsertQuote(
                quoteId,
                jobId,
                total,
                estDurationMins
            );

            _bookings.UpdateJobStatus(jobId, "Quote Submitted");

            return Ok(new
            {
                message = "Quote created successfully.",
                quoteId,
                total,
                estDurationMins
            });
        }

        // ===================== GET ALL INVOICES =====================
        [HttpGet("invoices")]
        public ActionResult<IEnumerable<ClientInvoice>> GetAllInvoices()
        {
            var invoices = _invoices.GetAllInvoices();
            return Ok(invoices);
        }

        // ===================== CREATE INVOICE =====================
        [HttpPost("invoices/create")]
        public IActionResult CreateInvoice([FromBody] InvoiceCreateRequest model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobID))
                return BadRequest("Invalid invoice data.");

            decimal total = 0m;
            string invoiceId = Guid.NewGuid().ToString();

            _invoices.InsertInvoiceHeader(invoiceId, model.JobID);

            foreach (var item in model.Items)
            {
                decimal unitPrice = _services.GetSupplyUnitPrice(item.SupplyID);
                decimal lineCost = unitPrice * item.Quantity;
                total += lineCost;

                _invoices.InsertInvoiceItem(
                    Guid.NewGuid().ToString(),
                    invoiceId,
                    item.SupplyID,
                    item.Quantity
                );
            }

            total += model.LabourCost + model.ExtraCost;

            _invoices.UpdateInvoiceTotal(invoiceId, total);
            _bookings.UpdateJobStatus(model.JobID, "Invoiced");

            return Ok(new
            {
                message = "Invoice created successfully.",
                invoiceId,
                total
            });
        }
    }
}
