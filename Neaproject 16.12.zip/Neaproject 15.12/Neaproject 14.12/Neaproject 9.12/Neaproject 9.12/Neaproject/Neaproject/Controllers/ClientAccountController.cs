﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Models;
using Neaproject.DataObjects;
using Neaproject.Methods;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client-account")]
    public class ClientAccountController : ControllerBase
    {
        private readonly ClientDataAccess _clients;

        public ClientAccountController(ClientDataAccess clients)
        {
            _clients = clients;
        }


        [HttpGet("{clientId}")] //get client info
        public ActionResult<Client> GetClient(string clientId)
        {
            var client = _clients.GetClientById(clientId); //get client records
            if (client == null) //if no client exists
                return NotFound("Client not found"); //output error message
            return Ok(client); //return full client object
        }

        [HttpPut("{clientId}")] //update client files
        public IActionResult UpdateClient(string clientId, [FromBody] ClientUpdate updated)
        {
            string hashed; //holds password hash or existing password

            if (string.IsNullOrWhiteSpace(updated.Password)) //if no new password
            {
                var existing = _clients.GetClientById(clientId); //get old password
                if(existing == null) //if client not found
        {
                    return NotFound(new { message = "Client not found." }); //output error message
                }
                hashed = existing.Password; //keep existing password
            }
            else //new password provided
            {
                hashed = PasswordHasher.Hash(updated.Password); //hash using PasswordHasher
            }

            _clients.UpdateClientFields( //update database
                clientId,
                updated.Email,
                updated.PhoneNum,
                updated.Address,
                updated.Postcode,
                hashed
            );

            return Ok(new { message = "Account updated successfully." }); //output success response
        }

    }
}