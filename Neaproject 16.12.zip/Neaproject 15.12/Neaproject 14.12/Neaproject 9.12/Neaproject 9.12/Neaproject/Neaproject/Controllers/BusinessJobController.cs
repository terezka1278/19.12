﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Models;
using System.Collections.Generic;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/business/jobs")]
    public class BusinessJobsController : ControllerBase
    {
        private readonly BookingDataAccess _bookings;

        public BusinessJobsController(BookingDataAccess bookings)
        {
            _bookings = bookings;
        }

        // ===================== GET ALL JOBS =====================
        [HttpGet]
        public ActionResult<IEnumerable<Job>> GetAll()
        {
            var jobs = _bookings.GetAllJobs();
            return Ok(jobs);
        }

        // ===================== MARK JOB COMPLETED =====================
        [HttpPut("{jobId}/complete")]
        public IActionResult MarkCompleted(string jobId)
        {
            _bookings.MarkJobCompleted(jobId);
            return NoContent();
        }
    }
}
