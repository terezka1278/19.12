﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using Neaproject.Methods;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/booking")]
    public class BookingController : ControllerBase
    {
        private readonly BookingDataAccess _bookings;
        private readonly ClientDataAccess _clients;
        private readonly SqliteDataAccess _db; // used for transactional booking logic

        public BookingController(
            BookingDataAccess bookings,
            ClientDataAccess clients,
            SqliteDataAccess db)
        {
            _bookings = bookings;
            _clients = clients;
            _db = db;
        }

        // ===============================
        // STEP 1 — Create Job
        // ===============================
        [HttpPost("step1")]
        public IActionResult Step1([FromBody] BookingStep1Request model)
        {
            if (model == null)
                return BadRequest(new { message = "No data sent." });

            string? clientIdToUse = model.ClientId;

            // ===============================
            // Logged-in user validation
            // ===============================
            if (!string.IsNullOrWhiteSpace(model.ClientId))
            {
                var client = _clients.GetClientById(model.ClientId);

                if (client == null)
                    return BadRequest(new { message = "Login invalid.", requiresLogin = true });

                if (!string.Equals(client.Email, model.Email.Trim(), StringComparison.OrdinalIgnoreCase))
                    return BadRequest(new { message = "Email not correct.", requiresLogin = true });

                clientIdToUse = model.ClientId;
            }
            else
            {
                // ===============================
                // Guest flow — account check
                // ===============================
                if (_clients.EmailExists(model.Email))
                {
                    return BadRequest(new
                    {
                        message = "Account exists. Please log in.",
                        requiresLogin = true
                    });
                }

                return BadRequest(new
                {
                    message = "No account found. Please create one.",
                    requiresAccount = true
                });
            }

            // ===============================
            // Create Job (transactional)
            // ===============================
            string jobId = Guid.NewGuid().ToString();
            string location = LocationFinder.GetRegion(model.Postcode);

            using (var conn = _db.GetConnection())
            {
                conn.Open();
                using (var tx = conn.BeginTransaction())
                {
                    using (var cmd = new SQLiteCommand(@"
                        INSERT INTO Jobs (
                            JobID, ClientID, ServiceID,
                            DateStarted, DateFinished,
                            Status, Summary, NumOfPoints, Location
                        )
                        VALUES (
                            @JobID, @ClientID, @ServiceID,
                            NULL, NULL,
                            'Not Started', @Summary, @Points, @Location
                        );", conn, tx))
                    {
                        cmd.Parameters.AddWithValue("@JobID", jobId);
                        cmd.Parameters.AddWithValue("@ClientID", clientIdToUse);
                        cmd.Parameters.AddWithValue("@ServiceID", model.Service);
                        cmd.Parameters.AddWithValue("@Summary", model.Summary);
                        cmd.Parameters.AddWithValue("@Points", model.Points);
                        cmd.Parameters.AddWithValue("@Location", location);
                        cmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }

            return Ok(new { clientId = clientIdToUse, jobId });
        }

        // ===============================
        // STEP 2 — Find available slots
        // ===============================
        [HttpPost("step2")]
        public IActionResult Step2([FromBody] BookingStep2Request model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobId))
                return BadRequest(new { message = "Invalid step 2 data." });

            if (model.Days == null || model.Days.Count == 0)
                return BadRequest(new { message = "Select at least one day." });

            var days = new List<DayOfWeek>();
            foreach (string d in model.Days)
                if (Enum.TryParse(d, true, out DayOfWeek parsed))
                    days.Add(parsed);

            var finder = new FindAvailableSlots(_db);
            var available = finder.FindAvailableDates(model.JobId, days, 62, 5);

            return Ok(new
            {
                jobId = model.JobId,
                suggestedDates = available
            });
        }

        // ===============================
        // STEP 2 — Confirm slot
        // ===============================
        [HttpPost("step2/confirm")]
        public IActionResult ConfirmStep2([FromBody] BookingStep2ConfirmRequest model)
        {
            if (model == null ||
                string.IsNullOrWhiteSpace(model.JobId) ||
                string.IsNullOrWhiteSpace(model.SelectedDate) ||
                string.IsNullOrWhiteSpace(model.SelectedSlot))
            {
                return BadRequest(new { message = "Invalid confirmation data." });
            }

            if (!DateTime.TryParse(model.SelectedDate, out var date))
                return BadRequest(new { message = "Invalid date format." });

            using (var conn = _db.GetConnection())
            {
                conn.Open();

                bool amTaken = false;
                bool pmTaken = false;

                // Get job region
                string? jobLocation;
                using (var locCmd = new SQLiteCommand(
                    "SELECT Location FROM Jobs WHERE JobID = @JID;", conn))
                {
                    locCmd.Parameters.AddWithValue("@JID", model.JobId);
                    jobLocation = locCmd.ExecuteScalar()?.ToString();
                }

                // Check conflicts
                using (var cmd = new SQLiteCommand(@"
                    SELECT A.TimeSlot, J.Location
                    FROM Appointments A
                    JOIN Jobs J ON A.JobID = J.JobID
                    WHERE ScheduledDate = @Date;", conn))
                {
                    cmd.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd"));

                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            int slot = r.GetInt32(0);
                            string existingLocation = r.GetString(1);

                            if (!string.Equals(existingLocation, jobLocation, StringComparison.OrdinalIgnoreCase))
                            {
                                return BadRequest(new
                                {
                                    message = "Cannot book this date due to region conflict.",
                                    regionConflict = true
                                });
                            }

                            if (slot == 1) amTaken = true;
                            else pmTaken = true;
                        }
                    }
                }

                if (model.SelectedSlot == "AM" && amTaken)
                    return BadRequest(new { message = "AM slot already booked." });

                if (model.SelectedSlot == "PM" && pmTaken)
                    return BadRequest(new { message = "PM slot already booked." });

                int slotToBook = model.SelectedSlot == "AM" ? 1 : 0;

                using (var insert = new SQLiteCommand(@"
                    INSERT INTO Appointments
                    (AppointmentID, JobID, ScheduledDate, TimeSlot)
                    VALUES
                    (@AID, @JID, @Date, @Slot);", conn))
                {
                    insert.Parameters.AddWithValue("@AID", Guid.NewGuid().ToString());
                    insert.Parameters.AddWithValue("@JID", model.JobId);
                    insert.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd"));
                    insert.Parameters.AddWithValue("@Slot", slotToBook);
                    insert.ExecuteNonQuery();
                }

                using (var update = new SQLiteCommand(
                    "UPDATE Jobs SET Status = 'Booked' WHERE JobID = @JID;", conn))
                {
                    update.Parameters.AddWithValue("@JID", model.JobId);
                    update.ExecuteNonQuery();
                }

                return Ok(new
                {
                    message = "Booking confirmed.",
                    jobId = model.JobId,
                    selectedDate = date.ToString("yyyy-MM-dd"),
                    timeSlot = model.SelectedSlot
                });
            }
        }
    }
}
