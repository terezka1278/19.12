﻿using Dapper;
using Neaproject.DataObjects;

namespace Neaproject.Data
{
    public class InvoiceDataAccess
    {
        private readonly SqliteDataAccess _db;

        public InvoiceDataAccess(SqliteDataAccess db)
        {
            _db = db;
        }

        // ===============================
        // CLIENT: get invoices
        // ===============================
        public IEnumerable<ClientInvoice> GetInvoicesForClient(string clientId)
        {
            using var conn = _db.GetConnection();

            return conn.Query<ClientInvoice>(@"
                SELECT 
                    i.InvoiceID,
                    j.JobID,
                    s.ServiceName,
                    i.FinalPrice,
                    i.PaymentStatus,
                    i.DepositPaid
                FROM Invoices i
                JOIN Jobs j ON i.JobID = j.JobID
                JOIN Services s ON j.ServiceID = s.ServiceID
                WHERE j.ClientID = @ClientId
                ORDER BY i.InvoiceID;",
                new { ClientId = clientId }
            );
        }

        // ===============================
        // BUSINESS: get all invoices
        // ===============================
        public IEnumerable<ClientInvoice> GetAllInvoices()
        {
            using var conn = _db.GetConnection();

            return conn.Query<ClientInvoice>(@"
                SELECT 
                    i.InvoiceID,
                    j.JobID,
                    s.ServiceName,
                    i.FinalPrice,
                    i.PaymentStatus,
                    i.DepositPaid
                FROM Invoices i
                JOIN Jobs j ON i.JobID = j.JobID
                JOIN Services s ON j.ServiceID = s.ServiceID
                ORDER BY i.InvoiceID;");
        }

        // ===============================
        // BUSINESS: create invoice header
        // ===============================
        public void InsertInvoiceHeader(string invoiceId, string jobId)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                INSERT INTO Invoices
                (InvoiceID, JobID, FinalPrice, PaymentStatus, DepositPaid)
                VALUES
                (@IID, @JID, 0, 'Unpaid', 0);",
                new
                {
                    IID = invoiceId,
                    JID = jobId
                });
        }

        // ===============================
        // BUSINESS: insert invoice items
        // ===============================
        public void InsertInvoiceItem(
            string invoiceItemId,
            string invoiceId,
            string supplyId,
            decimal quantity)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                INSERT INTO InvoiceItems
                (InvoiceItemID, InvoiceID, SupplyID, ActualQuantity)
                VALUES
                (@ID, @IID, @SID, @QTY);",
                new
                {
                    ID = invoiceItemId,
                    IID = invoiceId,
                    SID = supplyId,
                    QTY = quantity
                });
        }

        // ===============================
        // BUSINESS: update invoice total
        // ===============================
        public void UpdateInvoiceTotal(string invoiceId, decimal total)
        {
            using var conn = _db.GetConnection();

            conn.Execute(
                "UPDATE Invoices SET FinalPrice = @T WHERE InvoiceID = @ID;",
                new
                {
                    T = total,
                    ID = invoiceId
                });
        }
    }
}
