﻿using System.Data.SQLite;

namespace Neaproject.Data
{
    public class SqliteDataAccess
    {
        public SQLiteConnection GetConnection()
        {
            var dbPath = Path.Combine(AppContext.BaseDirectory, "database.db");
            return new SQLiteConnection($"Data Source={dbPath};Version=3;");
        }
    }
}
