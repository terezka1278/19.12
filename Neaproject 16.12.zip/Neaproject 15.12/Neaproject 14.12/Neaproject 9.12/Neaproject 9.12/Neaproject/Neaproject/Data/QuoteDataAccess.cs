﻿using Dapper;
using Neaproject.DataObjects;

namespace Neaproject.Data
{
    public class QuoteDataAccess
    {
        private readonly SqliteDataAccess _db;

        public QuoteDataAccess(SqliteDataAccess db)
        {
            _db = db;
        }

        // ===============================
        // Client: get quotes
        // ===============================
        public IEnumerable<ClientQuote> GetQuotesForClient(string clientId)
        {
            using var conn = _db.GetConnection();

            return conn.Query<ClientQuote>(@"
                SELECT 
                    q.QuoteID,
                    j.JobID,
                    s.ServiceName,
                    q.EstPrice,
                    q.EstDuration,
                    q.Accepted
                FROM Quotes q
                JOIN Jobs j ON q.JobID = j.JobID
                JOIN Services s ON j.ServiceID = s.ServiceID
                WHERE j.ClientID = @ClientId
                ORDER BY q.QuoteID;",
                new { ClientId = clientId }
            );
        }

        // ===============================
        // Business: get all quotes
        // ===============================
        public IEnumerable<ClientQuote> GetAllQuotes()
        {
            using var conn = _db.GetConnection();

            return conn.Query<ClientQuote>(@"
                SELECT 
                    q.QuoteID,
                    j.JobID,
                    s.ServiceName,
                    q.EstPrice,
                    q.EstDuration,
                    q.Accepted
                FROM Quotes q
                JOIN Jobs j ON q.JobID = j.JobID
                JOIN Services s ON j.ServiceID = s.ServiceID
                ORDER BY q.QuoteID;");
        }

        // ===============================
        // Client: accept / decline
        // ===============================
        public void SetQuoteAccepted(string quoteId, bool accepted)
        {
            using var conn = _db.GetConnection();

            conn.Execute(
                "UPDATE Quotes SET Accepted = @A WHERE QuoteID = @QID;",
                new
                {
                    A = accepted ? 1 : 0,
                    QID = quoteId
                });
        }

        // ===============================
        // Business: create quote
        // ===============================
        public void InsertQuote(
            string quoteId,
            string jobId,
            decimal estPrice,
            int estDuration)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                INSERT INTO Quotes
                (QuoteID, JobID, EstPrice, EstDuration, Accepted)
                VALUES
                (@QID, @JID, @Price, @Dur, 0);",
                new
                {
                    QID = quoteId,
                    JID = jobId,
                    Price = estPrice,
                    Dur = estDuration
                });
        }

        // ===============================
        // Business: quote items
        // ===============================
        public void InsertQuoteItem(
            string quoteItemId,
            string quoteId,
            string supplyId,
            decimal quantity,
            decimal unitPrice)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                INSERT INTO QuoteItems
                (QuoteItemID, QuoteID, SupplyID, Quantity, UnitPrice)
                VALUES
                (@ID, @QID, @SID, @Qty, @Price);",
                new
                {
                    ID = quoteItemId,
                    QID = quoteId,
                    SID = supplyId,
                    Qty = quantity,
                    Price = unitPrice
                });
        }

        // ===============================
        // Job status update via quote
        // ===============================
        public void UpdateJobStatusByQuote(string quoteId, string newStatus)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                UPDATE Jobs
                SET Status = @S
                WHERE JobID = (
                    SELECT JobID FROM Quotes WHERE QuoteID = @QID
                );",
                new
                {
                    S = newStatus,
                    QID = quoteId
                });
        }
    }
}
