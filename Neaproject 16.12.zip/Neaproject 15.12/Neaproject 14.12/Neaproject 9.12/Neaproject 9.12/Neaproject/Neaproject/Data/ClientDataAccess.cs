﻿using Dapper;
using Neaproject.Models;
using System.Data;

namespace Neaproject.Data
{
    public class ClientDataAccess
    {
        private readonly SqliteDataAccess _db;

        public ClientDataAccess(SqliteDataAccess db)
        {
            _db = db;
        }

        public User? GetUserByEmail(string email)
        {
            using var conn = _db.GetConnection();

            return conn.Query<User>(@"
                SELECT
                    ClientID AS Id,
                    Email,
                    Password,
                    Role
                FROM Clients
                WHERE Email = @Email;",
                new { Email = email }
            ).FirstOrDefault();
        }

        public (string ClientEmail, string BusinessEmail) GetEmailsForJob(string jobId)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            return conn.QuerySingle<(string, string)>(@"
        SELECT 
            c.Email AS ClientEmail,
            'YOUR_BUSINESS_EMAIL@gmail.com' AS BusinessEmail
        FROM Jobs j
        JOIN Clients c ON j.ClientID = c.ClientID
        WHERE j.JobID = @ID;
    ", new { ID = jobId });
        }


        public bool EmailExists(string email)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<int>(
                "SELECT COUNT(1) FROM Clients WHERE Email = @Email;",
                new { Email = email }
            ) > 0;
        }

        public bool PhoneExists(string phoneNum)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<int?>(
                "SELECT 1 FROM Clients WHERE PhoneNum = @PhoneNum LIMIT 1;",
                new { PhoneNum = phoneNum }
            ) != null;
        }

        public void CreateClient(Client client)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                INSERT INTO Clients
                    (ClientID, FirstName, LastName, Email, PhoneNum, Address, Postcode, Password, Role)
                VALUES
                    (@ClientID, @FirstName, @LastName, @Email, @PhoneNum, @Address, @Postcode, @Password, @Role);",
                client
            );
        }

        public Client? GetClientById(string clientId)
        {
            using var conn = _db.GetConnection();

            return conn.QueryFirstOrDefault<Client>(@"
                SELECT ClientID, FirstName, LastName, Email, PhoneNum, Address, Postcode, Password, Role
                FROM Clients
                WHERE ClientID = @ClientID;",
                new { ClientID = clientId }
            );
        }

        public void UpdateClientFields(
            string clientId,
            string? email,
            string? phone,
            string? address,
            string? postcode,
            string? password)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                UPDATE Clients
                SET
                    Email = COALESCE(@Email, Email),
                    PhoneNum = COALESCE(@PhoneNum, PhoneNum),
                    Address = COALESCE(@Address, Address),
                    Postcode = COALESCE(@Postcode, Postcode),
                    Password = COALESCE(@Password, Password)
                WHERE ClientID = @ClientID;",
                new
                {
                    ClientID = clientId,
                    Email = email,
                    PhoneNum = phone,
                    Address = address,
                    Postcode = postcode,
                    Password = password
                }
            );
        }
    }
}
