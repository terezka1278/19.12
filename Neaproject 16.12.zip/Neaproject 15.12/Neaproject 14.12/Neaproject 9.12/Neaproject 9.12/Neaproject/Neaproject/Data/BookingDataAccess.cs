﻿using Dapper;
using Neaproject.DataObjects;
using Neaproject.Models;
using System.Data;

namespace Neaproject.Data
{
    public class BookingDataAccess
    {
        private readonly SqliteDataAccess _db;

        public BookingDataAccess(SqliteDataAccess db)
        {
            _db = db;
        }

        // ===============================
        // Client bookings
        // ===============================
        public IEnumerable<ClientBooking> GetBookingsForClient(string clientId)
        {
            using var conn = _db.GetConnection();

            return conn.Query<ClientBooking>(@"
                SELECT 
                    j.JobID,
                    s.ServiceName,
                    a.ScheduledDate,
                    a.TimeSlot AS TimeSlotPm,
                    j.Status,
                    q.EstPrice
                FROM Jobs j
                JOIN Services s ON j.ServiceID = s.ServiceID
                JOIN Appointments a ON j.JobID = a.JobID
                LEFT JOIN Quotes q ON j.JobID = q.JobID
                WHERE j.ClientID = @ClientId
                ORDER BY date(a.ScheduledDate) DESC;",
                new { ClientId = clientId }
            );
        }

        public NextBooking? GetNextBookingForClient(string clientId)
        {
            using var conn = _db.GetConnection();

            var booking = conn.QueryFirstOrDefault<NextBooking>(@"
                SELECT 
                    j.JobID,
                    s.ServiceName,
                    a.ScheduledDate,
                    a.TimeSlot AS TimeSlotPm,
                    j.Status
                FROM Jobs j
                JOIN Services s ON j.ServiceID = s.ServiceID
                JOIN Appointments a ON j.JobID = a.JobID
                WHERE j.ClientID = @ClientId
                  AND date(a.ScheduledDate) >= date('now')
                  AND j.Status <> 'Completed'
                ORDER BY date(a.ScheduledDate) ASC
                LIMIT 1;",
                new { ClientId = clientId }
            );

            if (booking == null)
                return new NextBooking { HasBooking = false };

            booking.HasBooking = true;
            return booking;
        }

        // ===============================
        // Business jobs
        // ===============================
        public IEnumerable<Job> GetAllJobs()
        {
            using var conn = _db.GetConnection();

            return conn.Query<Job>(@"
                SELECT 
                    j.JobID,
                    c.FirstName || ' ' || c.LastName AS ClientName,
                    a.ScheduledDate,
                    j.Status,
                    s.ServiceName,
                    c.Address,
                    c.Postcode
                FROM Jobs j
                JOIN Clients c ON j.ClientID = c.ClientID
                JOIN Appointments a ON a.JobID = j.JobID
                JOIN Services s ON j.ServiceID = s.ServiceID
                ORDER BY a.ScheduledDate DESC;");
        }

        public void MarkJobCompleted(string jobId)
        {
            using var conn = _db.GetConnection();

            conn.Execute(@"
                UPDATE Jobs
                SET 
                    Status = 'Completed',
                    DateFinished = COALESCE(DateFinished, DATE('now'))
                WHERE JobID = @JobID;",
                new { JobID = jobId }
            );
        }

        public Job? GetJobById(string jobId)
        {
            using var conn = _db.GetConnection();

            return conn.QueryFirstOrDefault<Job>(
                "SELECT * FROM Jobs WHERE JobID = @JobID;",
                new { JobID = jobId }
            );
        }

        public int GetJobPoints(string jobId)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<int?>(
                "SELECT Points FROM Jobs WHERE JobID = @JobID;",
                new { JobID = jobId }
            ) ?? 1;
        }

        // ===============================
        // Cancellation helpers
        // ===============================
        public void DeleteAppointmentByJob(string jobId)
        {
            using var conn = _db.GetConnection();
            conn.Execute("DELETE FROM Appointments WHERE JobID = @JobID;",
                new { JobID = jobId });
        }

        public void DeleteQuoteByJob(string jobId)
        {
            using var conn = _db.GetConnection();
            conn.Execute("DELETE FROM Quotes WHERE JobID = @JobID;",
                new { JobID = jobId });
        }

        public void DeleteJob(string jobId)
        {
            using var conn = _db.GetConnection();
            conn.Execute("DELETE FROM Jobs WHERE JobID = @JobID;",
                new { JobID = jobId });
        }

        public void UpdateJobStatus(string jobId, string newStatus)
        {
            using var conn = _db.GetConnection();

            conn.Execute(
                "UPDATE Jobs SET Status = @S WHERE JobID = @JID;",
                new
                {
                    S = newStatus,
                    JID = jobId
                }
            );
        }

    }
}
