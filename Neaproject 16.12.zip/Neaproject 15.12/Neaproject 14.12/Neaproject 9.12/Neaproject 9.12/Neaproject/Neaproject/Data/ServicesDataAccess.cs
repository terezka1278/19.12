﻿using Dapper;

namespace Neaproject.Data
{
    public class ServiceDataAccess
    {
        private readonly SqliteDataAccess _db;

        public ServiceDataAccess(SqliteDataAccess db)
        {
            _db = db;
        }

        // ===============================
        // Get service linked to a job
        // ===============================
        public string GetServiceIdForJob(string jobId)
        {
            using var conn = _db.GetConnection();

            var serviceId = conn.ExecuteScalar<string>(
                "SELECT ServiceID FROM Jobs WHERE JobID = @ID;",
                new { ID = jobId }
            );

            if (string.IsNullOrWhiteSpace(serviceId))
                throw new Exception("No service found for this job.");

            return serviceId;
        }

        // ===============================
        // Base service price
        // ===============================
        public decimal GetServiceBasePrice(string serviceId)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<decimal>(
                "SELECT BasePrice FROM Services WHERE ServiceID = @ID;",
                new { ID = serviceId }
            );
        }

        // ===============================
        // Base service duration
        // ===============================
        public int GetServiceBaseDuration(string serviceId)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<int>(
                "SELECT BaseDuration FROM Services WHERE ServiceID = @ID;",
                new { ID = serviceId }
            );
        }

        // ===============================
        // Supplies required for a service
        // ===============================
        public IEnumerable<(string SupplyID, decimal UnitPrice, decimal Quantity)>
            GetServiceSupplies(string serviceId)
        {
            using var conn = _db.GetConnection();

            return conn.Query<(string, decimal, decimal)>(@"
                SELECT 
                    ss.SupplyID,
                    s.UnitPrice,
                    ss.Quantity
                FROM ServiceSupplies ss
                JOIN Supplies s ON ss.SupplyID = s.SupplyID
                WHERE ss.ServiceID = @ID;",
                new { ID = serviceId }
            );
        }

        // ===============================
        // Individual supply unit price
        // ===============================
        public decimal GetSupplyUnitPrice(string supplyId)
        {
            using var conn = _db.GetConnection();

            return conn.ExecuteScalar<decimal>(
                "SELECT UnitPrice FROM Supplies WHERE SupplyID = @ID;",
                new { ID = supplyId }
            );
        }
    }
}
