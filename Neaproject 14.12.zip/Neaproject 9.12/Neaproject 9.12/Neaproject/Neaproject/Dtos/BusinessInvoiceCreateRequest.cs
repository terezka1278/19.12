﻿namespace Neaproject.Dtos
{
    public class BusinessInvoiceCreateRequest
    {
        public string? JobID { get; set; }        // job the invoice belongs to
        public decimal MaterialCost { get; set; } // price of materials
        public int MaterialQty { get; set; }      // quantity used
        public decimal LabourCost { get; set; }   // labour charge
    }
}
