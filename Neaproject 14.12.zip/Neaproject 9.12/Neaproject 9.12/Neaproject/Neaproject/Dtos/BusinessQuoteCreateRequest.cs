﻿namespace Neaproject.Dtos
{
    public class BusinessQuoteCreateRequest
    {
        public string? JobID { get; set; }      // job ID quote belongs to
        public decimal EstPrice { get; set; }  // estimated price
        public int EstDuration { get; set; }   // duration in hours
        public string? Summary { get; set; }    // description of work
        public string? Supplies { get; set; }   // list of supplies needed
    }
}
