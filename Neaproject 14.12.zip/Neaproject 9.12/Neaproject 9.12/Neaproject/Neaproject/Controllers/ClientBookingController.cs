﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Dtos;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client-bookings")]
    public class ClientBookingsController : ControllerBase
    {
        private readonly SqliteDataAccess _db;

        public ClientBookingsController(SqliteDataAccess db)
        {
            _db = db; //database access
        }

        [HttpGet("{clientId}")] //get all bookings
        public ActionResult<IEnumerable<ClientBooking>> GetAllBookings(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message
            var bookings = _db.GetBookingsForClient(clientId); //fetch al bookings for this client
            return Ok(bookings); // return booking list
        }

        [HttpGet("{clientId}/next")]  //get upcoming bookings
        public ActionResult<NextBooking> GetNextBooking(string clientId) 
        {
            if (string.IsNullOrWhiteSpace(clientId)) //
                return BadRequest("ClientId is required.");
            var booking = _db.GetNextBookingForClient(clientId); //get next booking
            if (booking == null || !booking.HasBooking) //if no upcoming bookings
                return Ok(new NextBooking { HasBooking = false }); //output
            return Ok(booking); //return next booking
        }
   
        [HttpGet("{clientId}/quotes")] //get quotes for clients
        public ActionResult<IEnumerable<ClientQuote>> GetQuotes(string clientId) 
        {
            if (string.IsNullOrWhiteSpace(clientId)) //if cl
                return BadRequest("ClientId is required.");

            var quotes = _db.GetQuotesForClient(clientId);
            return Ok(quotes);
        }

        [HttpPost("quotes/{quoteId}/accept")]
        public IActionResult AcceptQuote(string quoteId)
        {
            if (string.IsNullOrWhiteSpace(quoteId))
                return BadRequest(new { message = "Invalid quote ID." });

            try
            {
                //mark quote as accepted
                _db.SetQuoteAccepted(quoteId, true);

                //update job status
                _db.UpdateJobStatusByQuote(quoteId, "Quote Accepted");

                return Ok(new { message = "Quote accepted." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("quotes/{quoteId}/decline")]
        public IActionResult DeclineQuote(string quoteId)
        {
            if (string.IsNullOrWhiteSpace(quoteId))
                return BadRequest(new { message = "Invalid quote ID." });

            try
            {
                //mark quote as declined
                _db.SetQuoteAccepted(quoteId, false);

                //update job status
                _db.UpdateJobStatusByQuote(quoteId, "Quote Declined");

                return Ok(new { message = "Quote declined." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }



        [HttpGet("{clientId}/invoices")] //get invoices for clients
        public ActionResult<IEnumerable<ClientInvoice>> GetInvoices(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message

            var invoices = _db.GetInvoicesForClient(clientId); //get all invoices
            return Ok(invoices); // return invoice list
        }

        [HttpDelete("{jobId}")]
        public IActionResult CancelBooking(string jobId)
        {
            if (string.IsNullOrWhiteSpace(jobId))
                return BadRequest(new { message = "Invalid job ID." });

            // 1. Check job exists
            var job = _db.GetJobById(jobId);
            if (job == null)
                return NotFound(new { message = "Job not found." });

            // 2. OPTIONAL (recommended): check job status
            if (job.Status == "Completed")
                return BadRequest(new { message = "Completed jobs cannot be cancelled." });

            // 3. Delete in correct order
            _db.DeleteAppointmentByJob(jobId);
            _db.DeleteQuoteByJob(jobId);
            _db.DeleteJob(jobId);

            return Ok(new { message = "Booking cancelled successfully." });
        }
    }

}
