﻿document.addEventListener("DOMContentLoaded", async () => {

    const jobId = localStorage.getItem("selectedJobId");
    if (!jobId) {
        alert("No booking selected.");
        return;
    }

    // -----------------------------
    // Load job + client details
    // -----------------------------
    const res = await fetch(`/api/business/jobs/${jobId}`);
    if (!res.ok) {
        alert("Failed to load job.");
        return;
    }

    const job = await res.json();

    document.getElementById("jobId").value = job.jobID;
    document.getElementById("clientId").value = job.clientID;
    document.getElementById("firstName").value = job.clientFirstName;
    document.getElementById("lastName").value = job.clientLastName;
    document.getElementById("email").value = job.email;
    document.getElementById("postcode").value = job.postcode;

    // -----------------------------
    // Live total preview
    // -----------------------------
    const inputs = [
        "materialCost",
        "materialQty",
        "labourCost",
        "extraCost"
    ];

    inputs.forEach(id =>
        document.getElementById(id)
            .addEventListener("input", updatePreview)
    );

    function updatePreview() {
        const material =
            Number(materialCost.value) * Number(materialQty.value);
        const labour = Number(labourCost.value);
        const extra = Number(extraCost.value);

        const total = material + labour + extra;

        document.getElementById("totalPreview").textContent =
            "Estimated Total: £" + total.toFixed(2);
    }

    // -----------------------------
    // Create invoice (backend calc)
    // -----------------------------
    document
        .getElementById("createInvoiceBtn")
        .addEventListener("click", async () => {

            const response = await fetch(
                "/api/business/documents/invoices/create",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        jobID: jobId,
                        materialCost: Number(materialCost.value),
                        materialQty: Number(materialQty.value),
                        labourCost: Number(labourCost.value),
                        extraCost: Number(extraCost.value)
                    })
                }
            );

            if (!response.ok) {
                alert("Failed to create invoice.");
                return;
            }

            alert("Invoice created successfully.");
            window.location.href = "business-documents.html";
        });
});
