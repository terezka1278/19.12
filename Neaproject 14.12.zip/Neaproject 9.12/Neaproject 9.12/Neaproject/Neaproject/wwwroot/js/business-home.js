﻿document.addEventListener("DOMContentLoaded", () => { //run when HTML page is fully loaded
    console.log("business-home.js loaded"); //debug message
    loadDashboard(); //load dashboard data
});


async function loadDashboard() { //main dashboard function
    const todayList = document.getElementById("JobsToday"); //today list element
    const weekTable = document.getElementById("week-calendar"); //week table element
    const monthTable = document.getElementById("month-calendar"); //month table element

    //check page elements exist
    if (!todayList || !weekTable || !monthTable) {
        console.error("Dashboard elements missing"); //debug error
        return;
    }

    const weekBody = weekTable.querySelector("tbody"); //week table body
    const monthBody = monthTable.querySelector("tbody"); //month table body

    //show loading messages
    todayList.innerHTML = "<li>Loading...</li>";
    weekBody.innerHTML = "";
    monthBody.innerHTML = "";

    try {
        const res = await fetch("/api/business/jobs"); //GET request to backend

        if (!res.ok) { //if backend fails
            todayList.innerHTML = "<li>Failed to load jobs.</li>";
            return;
        }

        const rawJobs = await res.json(); //get raw json
        const jobs = rawJobs.map(job => { //convert each job
            return normaliseJob(job); //normalise inconsistent fields
        });

        //render all dashboard sections
        renderToday(jobs, todayList);
        renderWeek(jobs, weekTable);
        renderMonth(jobs, monthTable);

    } catch (err) { //network/database crash
        console.error(err); //debug error
        todayList.innerHTML = "<li>Error loading jobs.</li>";
    }
}


function normaliseJob(raw) { //clean up job object as backend names differ, may change to not have to have this

    //get job ID (backend uses different spellings)
    let jobId;
    if (raw.jobId) {
        jobId = raw.jobId;
    } else if (raw.JobID) {
        jobId = raw.JobID;
    } else {
        jobId = raw.jobID;
    }

    //get client name
    let clientName;
    if (raw.clientName) {
        clientName = raw.clientName;
    } else {
        clientName = raw.ClientName;
    }

    //get scheduled date string
    let scheduledDateStr;
    if (raw.scheduledDate) {
        scheduledDateStr = raw.scheduledDate;
    } else {
        scheduledDateStr = raw.ScheduledDate;
    }

    //get status
    let status;
    if (raw.status) {
        status = raw.status;
    } else {
        status = raw.Status;
    }

    //service name
    let serviceName;
    if (raw.serviceName) {
        serviceName = raw.serviceName;
    } else {
        serviceName = raw.ServiceName;
    }

    //address
    let address;
    if (raw.address) {
        address = raw.address;
    } else {
        address = raw.Address;
    }

    //postcode
    let postcode;
    if (raw.postcode) {
        postcode = raw.postcode;
    } else {
        postcode = raw.Postcode;
    }

    //convert date string to Date object
    let dateObj;
    if (scheduledDateStr) {
        dateObj = new Date(scheduledDateStr);
    } else {
        dateObj = null;
    }

    //return clean job object
    return {
        jobId: jobId,
        clientName: clientName,
        status: status,
        serviceName: serviceName,
        address: address,
        postcode: postcode,
        dateObj: dateObj
    };
}

//compare two dates (same calendar day)
function isSameDate(d1, d2) {
    if (d1.getFullYear() === d2.getFullYear() &&
        d1.getMonth() === d2.getMonth() &&
        d1.getDate() === d2.getDate()) {
        return true;
    }
    else {
        return false;
    }
}

function renderToday(jobs, listEl) {
    const today = new Date(); //get today's date
    listEl.innerHTML = ""; //clear list

    //filter for today's jobs
    const todaysJobs = jobs.filter(job => {
        if (job.dateObj && isSameDate(job.dateObj, today)) {
            return true;
        } else {
            return false;
        }
    });

    //if no jobs today
    if (todaysJobs.length === 0) {
        listEl.innerHTML = "<li>No jobs scheduled for today.</li>";
        return;
    }

    //display each job
    todaysJobs.forEach(job => {
        const li = document.createElement("li");
        li.textContent = job.clientName + " – " +
            job.serviceName + " – " +
            job.address + " (" + job.status + ")";
        listEl.appendChild(li);
    });
}

function renderWeek(jobs, weekTable) {
    const tbody = weekTable.querySelector("tbody"); //table body
    tbody.innerHTML = "";

    const row = document.createElement("tr"); //one row (Mon–Fri)
    const today = new Date();

    const day = today.getDay(); //0=Sun, 1=Mon …
    let diffToMon;

    //calculate how far back Monday is
    if (day === 0) {
        diffToMon = -6; //if Sunday go back 6 days
    } else {
        diffToMon = 1 - day; //normal shift
    }

    const monday = new Date(today);
    monday.setDate(today.getDate() + diffToMon);

    //loop 5 days (Mon–Fri)
    for (let i = 0; i < 5; i++) {
        const current = new Date(monday);
        current.setDate(monday.getDate() + i);

        const cell = document.createElement("td"); //create day cell

        //add header with weekday text
        const header = document.createElement("div");
        header.classList.add("day-header");
        header.textContent = current.toLocaleDateString(undefined, {
            weekday: "short",
            day: "numeric",
            month: "short"
        });
        cell.appendChild(header);

        //find all jobs matching this day
        const dayJobs = jobs.filter(job => {
            if (job.dateObj && isSameDate(job.dateObj, current)) {
                return true;
            } else {
                return false;
            }
        });

        if (dayJobs.length === 0) {
            //no jobs that day
            const p = document.createElement("p");
            p.classList.add("no-jobs");
            p.textContent = "No jobs";
            cell.appendChild(p);
        } else {
            //list jobs inside cell
            dayJobs.forEach(job => {
                const p = document.createElement("p");
                p.classList.add("job-item");
                p.textContent = job.clientName + " – " +
                    job.serviceName + " – " +
                    job.address + " (" + job.status + ")";
                cell.appendChild(p);
            });
        }

        row.appendChild(cell); //add cell to row
    }

    tbody.appendChild(row); //add row to table
}


function renderMonth(jobs, monthTable) {
    const tbody = monthTable.querySelector("tbody");
    tbody.innerHTML = "";

    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth(); //0-11

    //find first day of month
    const firstDay = new Date(year, month, 1);

    let firstDayOfWeek = firstDay.getDay(); //0=Sun
    const mondayIndex = (firstDayOfWeek + 6) % 7; //shift to Monday=0

    const daysInMonth = new Date(year, month + 1, 0).getDate(); //count days

    let currentDay = 1 - mondayIndex; //start offset

    //up to 6 rows to show whole month
    for (let week = 0; week < 6; week++) {
        const row = document.createElement("tr");

        for (let d = 0; d < 7; d++) {
            const cell = document.createElement("td");

            //empty cells before/after real month days
            if (currentDay < 1 || currentDay > daysInMonth) {
                cell.classList.add("empty-day");
            }
            else {
                const dateObj = new Date(year, month, currentDay);

                const label = document.createElement("div"); //date number
                label.classList.add("date-label");
                label.textContent = currentDay.toString();
                cell.appendChild(label);

                //jobs for this date
                const dayJobs = jobs.filter(job => {
                    if (job.dateObj && isSameDate(job.dateObj, dateObj)) {
                        return true;
                    } else {
                        return false;
                    }
                });

                //display all jobs for that date
                if (dayJobs.length > 0) {
                    dayJobs.forEach(job => {
                        const p = document.createElement("p");
                        p.classList.add("job-item");
                        p.textContent =
                            job.clientName + " – " +
                            job.serviceName + " – " +
                            job.address + " (" + job.status + ")";
                        cell.appendChild(p);
                    });
                }
            }

            row.appendChild(cell);
            currentDay++; //move to next day
        }

        tbody.appendChild(row);

        //stop if all days are shown
        if (currentDay > daysInMonth) {
            break;
        }
    }
}
