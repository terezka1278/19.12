﻿// ===============================
// Business Documents + Bookings
// ===============================

// Holds selected booking
let selectedJobId = null;

document.addEventListener("DOMContentLoaded", () => {

    console.log("business-documents.js loaded");

    // -------------------------------
    // Load documents
    // -------------------------------
    loadAllQuotes();
    loadAllInvoices();
    loadAllBookings();

    // -------------------------------
    // Cancel booking button
    // -------------------------------
    const cancelBtn = document.getElementById("cancel");

    if (cancelBtn) {
        cancelBtn.addEventListener("click", async () => {

            if (!selectedJobId) {
                alert("Please select a booking first.");
                return;
            }

            if (!confirm("Are you sure you want to cancel this booking?")) return;

            const response = await fetch(`/api/client-bookings/${selectedJobId}`, {
                method: "DELETE"
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.message || "Failed to cancel booking.");
                return;
            }

            alert("Booking cancelled successfully.");
            location.reload();
        });
    }
});


// ===============================
// Load ALL bookings (business)
// ===============================
async function loadAllBookings() {

    const container = document.getElementById("manage-output");
    if (!container) return;

    container.textContent = "Loading bookings...";

    const response = await fetch("/api/business/jobs");

    if (!response.ok) {
        container.textContent = "Could not load bookings.";
        return;
    }

    const jobs = await response.json();

    if (!Array.isArray(jobs) || jobs.length === 0) {
        container.textContent = "No bookings found.";
        return;
    }

    const rows = jobs.map(job => `
        <tr class="booking-row"
            onclick="selectBooking('${job.jobID}', this)">
            <td>${job.jobID}</td>
            <td>${job.clientName}</td>
            <td>${job.serviceName}</td>
            <td>${job.status}</td>
        </tr>
    `).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Client</th>
                    <th>Service</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}


// ===============================
// Booking selection
// ===============================
function selectBooking(jobId, row) {
    selectedJobId = jobId;
    localStorage.setItem("selectedJobId", jobId);

    document.querySelectorAll(".booking-row")
        .forEach(r => r.classList.remove("selected"));

    row.classList.add("selected");

    console.log("Selected booking:", jobId);
}



// ===============================
// Load all quotes
// ===============================
async function loadAllQuotes() {

    const container = document.getElementById("quote-output");
    if (!container) return;

    container.textContent = "Loading quotes...";

    const res = await fetch("/api/business/documents/quotes");

    if (!res.ok) {
        container.textContent = "Could not load quotes.";
        return;
    }

    const quotes = await res.json();

    if (!Array.isArray(quotes) || quotes.length === 0) {
        container.textContent = "There are currently no quotes.";
        return;
    }

    const rows = quotes.map(q => {
        const acceptedText = q.accepted ? "Accepted" : "Pending";
        return `
            <tr>
                <td>${q.quoteID}</td>
                <td>${q.jobID}</td>
                <td>${q.serviceName}</td>
                <td>£${Number(q.estPrice).toFixed(2)}</td>
                <td>${q.estDuration} hrs</td>
                <td>${acceptedText}</td>
            </tr>
        `;
    }).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Quote ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Estimated Price</th>
                    <th>Estimated Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}


// ===============================
// Load all invoices
// ===============================
async function loadAllInvoices() {

    const container = document.getElementById("invoice-output");
    if (!container) return;

    container.textContent = "Loading invoices...";

    const res = await fetch("/api/business/documents/invoices");

    if (!res.ok) {
        container.textContent = "Could not load invoices.";
        return;
    }

    const invoices = await res.json();

    if (!Array.isArray(invoices) || invoices.length === 0) {
        container.textContent = "There are currently no invoices.";
        return;
    }

    const rows = invoices.map(inv => `
        <tr>
            <td>${inv.invoiceID}</td>
            <td>${inv.jobID}</td>
            <td>${inv.serviceName}</td>
            <td>£${Number(inv.finalPrice).toFixed(2)}</td>
            <td>${inv.paymentStatus}</td>
            <td>£${Number(inv.depositPaid).toFixed(2)}</td>
        </tr>
    `).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Final Price</th>
                    <th>Payment Status</th>
                    <th>Deposit Paid</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}
