﻿document.addEventListener("DOMContentLoaded", () => { //run only when HTML is fully loaded
    console.log("booking.js loaded"); //debugging log

    //get elements
    const form = document.getElementById("booking-form"); //get booking form
    const nextButton = document.getElementById("nextButton"); //get next button
    const stage1 = document.getElementById("stage1"); //get stage 1
    const stage2 = document.getElementById("stage2"); //get stage 2
    const output = document.getElementById("stage1-output"); // get output element
    const confirmPopup = document.getElementById("confirm-popup"); //get confirmation popup
    const confirmPopupMessage = document.getElementById("confirm-popup-message"); //get confirmation message
    const confirmPopupClose = document.getElementById("confirm-popup-close"); //get confirmation popup close button

    if (!form || !nextButton || !stage1 || !stage2) { //if elements not found
        console.log("Booking form or stages not found"); //debugging log
        return; //stop
    }

    //STEP 1 - Create job 
    nextButton.addEventListener("click", async () => {
        //read values from form 
        const firstName = document.getElementById("firstname").value.trim(); //read first name
        const lastName = document.getElementById("lastname").value.trim(); //read last name
        const email = document.getElementById("email").value.trim(); //read email
        const phoneNum = document.getElementById("phoneNum").value.trim(); //read phone number
        const address = document.getElementById("address").value.trim(); //read address
        const postcode = document.getElementById("postcode").value.trim(); //read postcode
        const service = document.getElementById("service").value;//read service
        const pointsVal = document.getElementById("points").value.trim();//read points
        const summary = document.getElementById("summary").value.trim();//read summary
        const points = Number(pointsVal); //convert from string to number

        if (!firstName || !lastName || !email || !phoneNum || !address || !postcode || !service || !summary || !points) { //if any required field is missing
            if (output) output.textContent = "Please fill in all required fields."; //ouput error message
            return; //stop
        }

        //create JSON object to send to backend API
        const body = {
            firstName, lastName, email, phoneNum, address, postcode, service, points, summary,
            clientId: localStorage.getItem("clientID") || null //include clientId if logged in
        };

        console.log("Sending booking step 1 request", body); //debugging log
        if (output) output.textContent = "Saving your details..."; //ouput message

        //send POST request to backend API
        const response = await fetch("/api/booking/step1", { 
            method: "POST",
            headers: { "Content-Type": "application/json" }, //tells it is JSON
            body: JSON.stringify(body) //turn JS object into JSON string
        });

        const data = await response.json(); //wait for response
        console.log("Booking step 1 response", response.status, data); //debugging log

        if (!response.ok) { //if HTTP status is not okay then stop
            if (data.requiresLogin) { //if user needs to log in
                if (output) { 
                    output.textContent = "You already have an account. Please log in to continue."; //ouput error message
                }
                localStorage.setItem("returnToBooking", "true"); //remember to return to booking after login

                //redirect to login page after 1.5 seconds
                setTimeout(() => { 
                    window.location.href = "login.html";
                }, 1500);

                return; //stop
            }
            if (data.requiresAccount) { //if user needs to create account
                if (output) { 
                    output.textContent = "No account found. Please create an account first."; //ouput error message
                }
                localStorage.setItem("returnToBooking", "true"); //remember to return to booking after account creation

                setTimeout(() => { //after 1.5 seconds redirect to create account page
                    window.location.href = "create-account.html";
                }, 1500);

                return; //stop
            }
            if (output) { //if any other error
                output.textContent = "There was a problem saving your details."; //ouput error message
            }
            return; //stop
        }

        //get data from API
        const clientId = data.clientId; //get clientID
        const jobId = data.jobId; //get JobId

        // store booking state in local storage
        localStorage.setItem("clientID", clientId); //save clientID
        localStorage.setItem("clientEmail", email); //save email
        localStorage.setItem("currentJobID", jobId); //save jobID
        localStorage.setItem("clientName", firstName + " " + lastName); //save client name

        if (output) {
            output.textContent = "Details saved! Continue to Step 2."; //ouput message
        }
    });

    //STEP 2 - Select dates
    form.addEventListener("submit", async (e) => { //when form is submitted
        e.preventDefault(); //stop form from submitting normally

        const dateOutputDiv = document.getElementById("date-output");//get date ouput element
        if (!dateOutputDiv) { //if it doesn't exist
            console.warn("date-output div not found"); //debugging log
            return; //stop
        }

        const dayCheckboxes = document.querySelectorAll(".days"); //get all checkboxes with class="days"
        const selectedDays = []; //array to store selected days

        dayCheckboxes.forEach(cb => { //for each checkbox
            if (cb.checked) { //if checked
                selectedDays.push(cb.name); //add name to array
            }
        });

        if (selectedDays.length === 0) { //if no days selected
            dateOutputDiv.textContent = "Please select at least one day."; //ouput error message
            return; //stop
        }

        const jobId = localStorage.getItem("currentJobID"); //read value of currentJobID from localStorage
        if (!jobId) { // if not found
            dateOutputDiv.textContent = "Missing job information. Please complete Stage 1 again."; //ouput error message
            return; //stop
        }

        //create JSON object to send to backend API
        const body = {
            jobId: jobId,
            days: selectedDays
        };

        console.log("Sending booking step 2 request", body); //debugging log
        dateOutputDiv.textContent = "Finding available dates..."; //ouput message

        //send POST request to backend API
        const response = await fetch("/api/booking/step2", {
            method: "POST",
            headers: { "Content-Type": "application/json" }, //tells it it is JSON
            body: JSON.stringify(body) //turn JS object into JSON string
        });

        const data = await response.json(); //wait for response
        console.log("Booking step 2 response", response.status, data); //debugging log

        if (!response.ok) { //if HTTP status is not OK then stop
            dateOutputDiv.textContent = "There was a problem finding available dates."; //ouput error message
            return; //stop
        }

        const suggested = data.suggestedDates || []; //get available dates from response
        if (suggested.length === 0) { //if no dates found
            dateOutputDiv.textContent = "No available dates found in the next few weeks."; //ouput message
            return; //stop
        }

        renderSuggestedDates(dateOutputDiv, suggested, jobId);   //display radio buttons for available dates found
    });

    function renderSuggestedDates(container, suggestedDates, jobId) { //function to display available dates and time slots
        container.innerHTML = ""; //clear previous content

        const info = document.createElement("p"); //create paragraph element
        info.textContent = "Please choose a date and time:"; //set text
        container.appendChild(info); //add inside container

        const list = document.createElement("div"); //create div to hold radio buttons

        suggestedDates.forEach(item => { //loop through each available date object

            const label = document.createElement("label"); //create label element

            const pretty = new Date(item.date).toLocaleDateString(undefined, { //convert to readable date
                weekday: "long",
                year: "numeric",
                month: "short",
                day: "numeric"
            });

            label.append(`${pretty} `); //add readable date text

            //AM RADIO BUTTON
            if (item.amAvailable) {
                const amRadio = document.createElement("input"); //create radio input
                amRadio.type = "radio";
                amRadio.name = "chosenSlot"; //name allows one selection
                amRadio.value = item.date + "|AM"; //date + time
                label.appendChild(amRadio);
                label.append(" AM "); //text next to radio
            } else {
                label.append(" (AM full) "); //text if full
            }

            //PM RADIO BUTTON
            if (item.pmAvailable) {
                const pmRadio = document.createElement("input");
                pmRadio.type = "radio";
                pmRadio.name = "chosenSlot";
                pmRadio.value = item.date + "|PM";
                label.appendChild(pmRadio);
                label.append(" PM ");
            } else {
                label.append(" (PM full) ");
            }

            list.appendChild(label); //add label to list
            list.appendChild(document.createElement("br")); //line break
        });

        container.appendChild(list); //add list of radio buttons to container

        btn = document.createElement("button"); //create confirm button
        btn.type = "button";
        btn.id = "confirm-date";
        btn.textContent = "Confirm selection";
        container.appendChild(btn);

        let statusP = document.getElementById("date-status"); //find status message element
        if (!statusP) {
            statusP = document.createElement("p");
            statusP.id = "date-status";
            container.appendChild(statusP);
        }

        btn.onclick = async () => { //when confirm button clicked
            const selectedRadio = container.querySelector("input[name='chosenSlot']:checked"); //find user choice
            if (!selectedRadio) {
                statusP.textContent = "Please select a date and time."; //error message
                return;
            }

            const parts = selectedRadio.value.split("|");
            const selectedDate = parts[0]; //extract date
            const selectedSlot = parts[1]; //AM or PM

            statusP.textContent = "Confirming your booking..."; //loading message

            console.log("Sending confirm:", { jobId, selectedDate, selectedSlot }); //debugging log

            //send POST request to backend API
            const response = await fetch("/api/booking/step2/confirm", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ jobId, selectedDate, selectedSlot })
            });

            const data = await response.json();
            console.log("Booking confirm response", response.status, data);

            if (!response.ok) {
                if (data.regionConflict) {
                    statusP.textContent = data.message;
                    return;
                }
                statusP.textContent = "There was a problem confirming your booking.";
                return;
            }

            //save details
            localStorage.setItem("lastBookingDate", data.selectedDate);
            localStorage.setItem("lastBookingJobId", data.jobId);
            localStorage.setItem("lastBookingSlot", data.timeSlot);

            const clientName = localStorage.getItem("clientName") || "Client";

            const niceDate = new Date(data.selectedDate).toLocaleDateString(undefined, {
                weekday: "long",
                year: "numeric",
                month: "short",
                day: "numeric"
            });

            if (confirmPopup && confirmPopupMessage) {
                confirmPopupMessage.textContent = `Thank you, ${clientName}. Your booking has been confirmed for ${niceDate} (${data.timeSlot}).`;
                confirmPopup.hidden = false;
            } else {
                statusP.textContent = "Booking confirmed!";
            }

            if (confirmPopupClose && confirmPopup) {
                confirmPopupClose.addEventListener("click", () => {
                    confirmPopup.hidden = true;
                });
            }
        };
    }

    
});
