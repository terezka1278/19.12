﻿using System.Data;
using System.Data.SQLite;
using System.Linq;
using Dapper;
using Neaproject.Models;
using Neaproject.Dtos;

namespace Neaproject.Data
{
    public class SqliteDataAccess
    {
        private readonly string _connString = "Data Source=database.db";
        public SQLiteConnection GetConnection()  //create a new SQLiteconnection object
        {
            return new SQLiteConnection(LoadConnectionString()); 
        }

        private string LoadConnectionString() //build full connection string
        {
            var dbPath = Path.Combine(AppContext.BaseDirectory, "database.db"); //give path to find database
            return $"Data Source={dbPath};Version=3;"; // starndard SQLite format
        }

        //login
        public User? GetUserByEmail(string email)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString())) //open database connection
            {
                var param = new { Email = email }; //dapper query
                var user = cnn.Query<User>(
                    @"SELECT
                          ClientID AS Id,
                          Email,
                          Password,
                          Role
                      FROM Clients
                      WHERE Email = @Email;",
                    param
                ).FirstOrDefault(); //return first row 
                return user; //return user object
            }
        }

        //check email and phone exist
        public bool EmailExists(string email)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))  //open dataase connection
            {
                int count = cnn.ExecuteScalar<int>( //return integer count
                    "SELECT COUNT(1) FROM Clients WHERE Email = @Email;",
                    new { Email = email }
                );
                return count > 0; //true if at least one match
            }
        }
        public bool PhoneExists(string phoneNum)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString())) //open database connection
            {
                const string sql = "SELECT 1 FROM Clients WHERE PhoneNum = @PhoneNum LIMIT 1;"; 
                var result = cnn.ExecuteScalar<int?>(sql, new { PhoneNum = phoneNum });
                return result != null; //true if found
            }
        }

        //create client
        public void CreateClient(Client client)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString())) //open database
            {
                //sql insert client
                const string sql = @"
            INSERT INTO Clients
                (ClientID, FirstName, LastName, Email, PhoneNum, Address, Postcode, Password, Role)
            VALUES
                (@ClientID, @FirstName, @LastName, @Email, @PhoneNum, @Address, @Postcode, @Password, @Role);
        ";
                try
                {
                    cnn.Execute(sql, client); 
                }
                catch (SQLiteException ex)
                {
                    if (ex.Message.Contains("PhoneNum"))
                    {
                        throw new Exception("Phone number already in use.");
                    }
                    if (ex.Message.Contains("Email"))
                    {
                        throw new Exception("Email already in use."); 
                    }
                }
            }
        }
 
        //all bookings for client
        public IEnumerable<ClientBooking> GetBookingsForClient(string clientId)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                j.JobID,
                s.ServiceName AS ServiceName,
                a.ScheduledDate,
                a.TimeSlot AS TimeSlotPm,
                j.Status,
                q.EstPrice
            FROM Jobs j
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            INNER JOIN Appointments a ON j.JobID = a.JobID
            LEFT JOIN Quotes q ON j.JobID = q.JobID 
            WHERE j.ClientID = @ClientId
            ORDER BY date(a.ScheduledDate) DESC;
        ";
                return cnn.Query<ClientBooking>(sql, new { ClientId = clientId }); //return list of client bookings
            }
        }

        //get upcoming bookings
        public NextBooking? GetNextBookingForClient(string clientId)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                j.JobID,
                s.ServiceName AS ServiceName,
                a.ScheduledDate,
                a.TimeSlot AS TimeSlotPm,
                j.Status
            FROM Jobs j
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            INNER JOIN Appointments a ON j.JobID = a.JobID
            WHERE j.ClientID = @ClientId
              AND date(a.ScheduledDate) >= date('now')
              AND j.Status <> 'Completed'
            ORDER BY date(a.ScheduledDate) ASC
            LIMIT 1;
        ";
                var booking = cnn.QueryFirstOrDefault<NextBooking>(sql, new { ClientId = clientId }); 
                if (booking == null) //if no booking
                {
                    return new NextBooking { HasBooking = false }; //return empty object
                }
                booking.HasBooking = true; //mark that booking exists
                return booking; //return booking object
            }
        }

        //client quotes
        public IEnumerable<ClientQuote> GetQuotesForClient(string clientId)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                q.QuoteID,
                j.JobID,
                s.ServiceName,
                q.EstPrice,
                q.EstDuration,
                q.Accepted
            FROM Quotes q
            INNER JOIN Jobs j ON q.JobID = j.JobID
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            WHERE j.ClientID = @ClientId
            ORDER BY q.QuoteID;
        ";
                return cnn.Query<ClientQuote>(sql, new { ClientId = clientId }); //return list of client records
            }
        }

        //client invoices
        public IEnumerable<ClientInvoice> GetInvoicesForClient(string clientId)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                i.InvoiceID,
                j.JobID,
                s.ServiceName,
                i.FinalPrice,
                i.PaymentStatus,
                i.DepositPaid
            FROM Invoices i
            INNER JOIN Jobs j ON i.JobID = j.JobID
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            WHERE j.ClientID = @ClientId
            ORDER BY i.InvoiceID;
        ";
                return cnn.Query<ClientInvoice>(sql, new { ClientId = clientId }); //return lit of client invoice records
            }
        }

        
        public Client? GetClientById(string clientId) //get client record by id
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT ClientID, FirstName, LastName, Email, PhoneNum, Address, Postcode, Password, Role
            FROM Clients
            WHERE ClientID = @ClientID;
        ";
                return cnn.QueryFirstOrDefault<Client>(sql, new { ClientID = clientId });//return client 
            }
        }

        //update chosen fields
        public void UpdateClientFields(string clientId, string? email, string? phone, string? address, string? postcode, string? password)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            UPDATE Clients
            SET
                Email = COALESCE(@Email, Email),
                PhoneNum = COALESCE(@PhoneNum, PhoneNum),
                Address = COALESCE(@Address, Address),
                Postcode = COALESCE(@Postcode, Postcode),
                Password = COALESCE(@Password, Password)
            WHERE ClientID = @ClientID;
        ";
                //COALSCE keeps old value when parameter is null
                cnn.Execute(sql, new
                {
                    ClientID = clientId,
                    Email = email,
                    PhoneNum = phone,
                    Address = address,
                    Postcode = postcode,
                    Password = password
                });
            }
        }

        //get all jobs for business
        public IEnumerable<Job> GetAllJobs()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                j.JobID,
                c.FirstName || ' ' || c.LastName AS ClientName,
                a.ScheduledDate AS ScheduledDate,
                j.Status,
                s.ServiceName,      -- NEW
                c.Address,          -- NEW
                c.Postcode          -- NEW
            FROM Jobs j
            JOIN Clients c    ON j.ClientID  = c.ClientID
            JOIN Appointments a ON a.JobID   = j.JobID
            JOIN Services s   ON j.ServiceID = s.ServiceID
            ORDER BY a.ScheduledDate DESC;
        ";
                return cnn.Query<Job>(sql); //return list of job records
            }
        }

        //mark job as completed
        public void MarkJobCompleted(string jobId)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
                    UPDATE Jobs
                    SET 
                        Status = 'Completed',
                        DateFinished = COALESCE(DateFinished, DATE('now'))
                    WHERE JobID = @JobID;
                ";
                cnn.Execute(sql, new { JobID = jobId }); //execute update with jobID
            }
        }

        //get all quotes
        public IEnumerable<ClientQuote> GetAllQuotes()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                q.QuoteID,
                j.JobID,
                s.ServiceName,
                q.EstPrice,
                q.EstDuration,
                q.Accepted
            FROM Quotes q
            INNER JOIN Jobs j ON q.JobID = j.JobID
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            ORDER BY q.QuoteID;
        ";
                return cnn.Query<ClientQuote>(sql); //return list of all quotes
            }
        }

        //get all invoices
        public IEnumerable<ClientInvoice> GetAllInvoices()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sql = @"
            SELECT 
                i.InvoiceID,
                j.JobID,
                s.ServiceName,
                i.FinalPrice,
                i.PaymentStatus,
                i.DepositPaid
            FROM Invoices i
            INNER JOIN Jobs j ON i.JobID = j.JobID
            INNER JOIN Services s ON j.ServiceID = s.ServiceID
            ORDER BY i.InvoiceID;
        ";
                return cnn.Query<ClientInvoice>(sql); //return list of all invoices
            }
        }
        public void CreateQuote(string quoteId, string jobId, decimal estPrice,
    int estDuration, string supplies, string summary)
        {
            using (var conn = GetConnection())
            {
                conn.Open();

                using (var cmd = new SQLiteCommand(@"
            INSERT INTO Quotes
            (QuoteID, JobID, EstPrice, EstDuration, Supplies, Summary, Accepted)
            VALUES
            (@QID, @JID, @Price, @Dur, @Sup, @Sum, 0);", conn))
                {
                    cmd.Parameters.AddWithValue("@QID", quoteId);
                    cmd.Parameters.AddWithValue("@JID", jobId);
                    cmd.Parameters.AddWithValue("@Price", estPrice);
                    cmd.Parameters.AddWithValue("@Dur", estDuration);
                    cmd.Parameters.AddWithValue("@Sup", supplies);
                    cmd.Parameters.AddWithValue("@Sum", summary);
                    cmd.ExecuteNonQuery();
                }
            }

        }

        public void SetQuoteAccepted(string quoteId, bool accepted)
        {
            using (var conn = GetConnection())
            {
                conn.Open();

                using (var cmd = new SQLiteCommand(
                    "UPDATE Quotes SET Accepted = @A WHERE QuoteID = @QID;", conn))
                {
                    cmd.Parameters.AddWithValue("@A", accepted ? 1 : 0);
                    cmd.Parameters.AddWithValue("@QID", quoteId);
                    cmd.ExecuteNonQuery();
                }
            }
        }


        public void UpdateJobStatus(string jobId, string newStatus)
        {
            using (var conn = GetConnection())
            {
                conn.Open();

                using (var cmd = new SQLiteCommand(
                    "UPDATE Jobs SET Status = @S WHERE JobID = @JID;", conn))
                {
                    cmd.Parameters.AddWithValue("@S", newStatus);
                    cmd.Parameters.AddWithValue("@JID", jobId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateJobStatusByQuote(string quoteId, string newStatus)
        {
            using (var conn = GetConnection())
            {
                conn.Open();

                using (var cmd = new SQLiteCommand(@"
            UPDATE Jobs
            SET Status = @S
            WHERE JobID = (SELECT JobID FROM Quotes WHERE QuoteID = @QID);
        ", conn))
                {
                    cmd.Parameters.AddWithValue("@S", newStatus);
                    cmd.Parameters.AddWithValue("@QID", quoteId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void CreateInvoice(string invoiceId, string jobId,
    decimal materialCost, int materialQty, decimal labourCost, decimal totalPrice)
        {
            using (var conn = GetConnection())
            {
                conn.Open();

                using (var cmd = new SQLiteCommand(@"
            INSERT INTO Invoices
            (InvoiceID, JobID, MaterialCost, MaterialQty, LabourCost, FinalPrice, PaymentStatus, DepositPaid)
            VALUES
            (@IID, @JID, @MCost, @MQty, @L, @Total, 'Unpaid', 0);
        ", conn))
                {
                    cmd.Parameters.AddWithValue("@IID", invoiceId);
                    cmd.Parameters.AddWithValue("@JID", jobId);
                    cmd.Parameters.AddWithValue("@MCost", materialCost);
                    cmd.Parameters.AddWithValue("@MQty", materialQty);
                    cmd.Parameters.AddWithValue("@L", labourCost);
                    cmd.Parameters.AddWithValue("@Total", totalPrice);

                    cmd.ExecuteNonQuery();
                }
            }
        }


        public Job? GetJobById(string jobId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                return conn.QueryFirstOrDefault<Job>(
                    "SELECT * FROM Jobs WHERE JobID = @JobID;",
                    new { JobID = jobId }
                );
            }
        }

        public void DeleteAppointmentByJob(string jobId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                conn.Execute(
                    "DELETE FROM Appointments WHERE JobID = @JobID;",
                    new { JobID = jobId }
                );
            }
        }

        public void DeleteQuoteByJob(string jobId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                conn.Execute(
                    "DELETE FROM Quotes WHERE JobID = @JobID;",
                    new { JobID = jobId }
                );
            }
        }

        public void DeleteJob(string jobId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                conn.Execute(
                    "DELETE FROM Jobs WHERE JobID = @JobID;",
                    new { JobID = jobId }
                );
            }
        }
        public string GetServiceIdForJob(string jobId)
        {
            using var conn = GetConnection();
            conn.Open();

            var serviceId = conn.ExecuteScalar<string>(
                "SELECT ServiceID FROM Jobs WHERE JobID = @ID;",
                new { ID = jobId }
            );

            if (string.IsNullOrEmpty(serviceId))
                throw new Exception("No service found for the given job.");

            return serviceId;
        }


        public decimal GetServiceBasePrice(string serviceId)
        {
            using var conn = GetConnection();
            conn.Open();

            return conn.ExecuteScalar<decimal>(
                "SELECT BasePrice FROM Services WHERE ServiceID = @ID;",
                new { ID = serviceId }
            );
        }

        public IEnumerable<(string SupplyID, decimal UnitPrice, decimal Quantity)>
    GetServiceSupplies(string serviceId)
        {
            using var conn = GetConnection();
            conn.Open();

            return conn.Query<(string, decimal, decimal)>(@"
        SELECT 
            ss.SupplyID,
            s.UnitPrice,
            ss.Quantity
        FROM ServiceSupplies ss
        JOIN Supplies s ON ss.SupplyID = s.SupplyID
        WHERE ss.ServiceID = @ID;
    ", new { ID = serviceId });
        }

        public void InsertQuote(string quoteId, string jobId, decimal estPrice)
        {
            using var conn = GetConnection();
            conn.Open();

            conn.Execute(@"
        INSERT INTO Quotes (QuoteID, JobID, EstPrice)
        VALUES (@QID, @JID, @Price);
    ", new { QID = quoteId, JID = jobId, Price = estPrice });
        }

        public void InsertQuoteItem(
    string quoteItemId,
    string quoteId,
    string supplyId,
    decimal quantity,
    decimal unitPrice)
        {
            using var conn = GetConnection();
            conn.Open();

            conn.Execute(@"
        INSERT INTO QuoteItems
        (QuoteItemID, QuoteID, SupplyID, Quantity, UnitPrice)
        VALUES
        (@ID, @QID, @SID, @Qty, @Price);
    ",
            new
            {
                ID = quoteItemId,
                QID = quoteId,
                SID = supplyId,
                Qty = quantity,
                Price = unitPrice
            });
        }


    }
}