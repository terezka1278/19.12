﻿document.addEventListener("DOMContentLoaded", () => { //runs only when the HTML is fully loaded
    console.log("client-account.js loaded"); //debugging log
    const clientId = localStorage.getItem("clientID"); // Retrieve client ID from local storage

    if (!clientId) { //if no client ID found
        window.location.href = "login.html"; //redirect to login page
        return; //stop
    }
    loadCurrentClientInfo(clientId); //load current clientID

    const form = document.getElementById("account-changes"); //get form element
    form.addEventListener("submit", updateClientAccount); //run updateClientAccount when form is submitted
});

async function loadCurrentClientInfo(clientId) { //function to load current client info
    const response = await fetch(`/api/client-account/${clientId}`); //GET response from backend API
    if (!response.ok) { //if HTTP response is not OK
        console.error("Failed to load client info"); //debugging log
        return; //show
    }
    const client = await response.json(); //wait for response

    //insert current client info into HTML elements
    document.getElementById("current-address").innerHTML = `<p>${client.address}</p>`;
    document.getElementById("current-postcode").innerHTML = `<p>${client.postcode}</p>`;
    document.getElementById("current-email").innerHTML = `<p>${client.email}</p>`;
    document.getElementById("current-phoneNum").innerHTML = `<p>${client.phoneNum}</p>`;
    document.getElementById("current-password").innerHTML = `<p>********</p>`; //never show actual password
}

async function updateClientAccount(e) { //function to update client account
    e.preventDefault(); //stop form from submitting normally

    const clientId = localStorage.getItem("clientID"); //get client ID from local storage
    const formData = new FormData(e.target); //get form data

    //create JSON object with form data
    const body = {
        address: formData.get("address") || null,
        postcode: formData.get("postcode") || null,
        email: formData.get("email") || null,
        phoneNum: formData.get("phoneNum") || null,
        password: formData.get("password") || null
    };

    Object.keys(body).forEach(key => { //loop though each key in body
        if (!body[key] || body[key].trim() === "") body[key] = null; //if value is empty or blank replace with null
    });

    //send PUT request to backend API to update client account
    const response = await fetch(`/api/client-account/${clientId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" }, //tells it is JSON data
        body: JSON.stringify(body) //convert body object to JSON string
    });

    if (response.ok) { //if HTTP response is OK
        alert("Your account has been updated!"); //output message
        loadCurrentClientInfo(clientId); //reload current clientID
    } else {
        alert("Update failed."); //output message
    }
}