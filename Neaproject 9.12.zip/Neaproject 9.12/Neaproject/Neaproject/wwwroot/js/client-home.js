document.addEventListener("DOMContentLoaded", () => { //run only when HTML is fully loaded
    console.log("client-home.js loaded"); //debugging log

    const clientId = localStorage.getItem("clientID"); //get clientID from local storage

    if (!clientId) { // if no clientID found
        window.location.href = "login.html"; //redirect to login page
        return; //stop
    }

    const upcomingDiv = document.getElementById("upcoming-output"); //get upcoming bookings element
    const previousDiv = document.getElementById("previous-output"); //get previous bookings element

    loadNextBooking(clientId, upcomingDiv); //load next booking
    loadAllBookings(clientId, previousDiv); //load all bookings
});

async function loadNextBooking(clientId, container) { //funtion to load next booking
    if (!container) return; //if no container, stop

    container.textContent = "Loading next booking..."; //ouput loading message
    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}/next`); //send GET request to backend API and insert ID into URL

    if (!response.ok) { //if HTTP response not OK
        container.textContent = "Could not load upcoming booking."; //output error message
        return; //stop
    }
    const data = await response.json(); //wait for response

    if (!data.hasBooking) { //if no upcoming booking
        container.textContent = "You have no upcoming bookings."; //output message
        return; //stop
    }

    const dateStr = new Date(data.scheduledDate).toLocaleDateString(); //convert date to readable string
    const timeSlot = data.timeSlotPm ? "PM" : "AM"; //determine time slot

    //insert HTML showing booking details
    container.innerHTML = `
    <p><strong>Service:</strong> ${data.serviceName}</p>
    <p><strong>Date:</strong> ${dateStr} (${timeSlot})</p>
    <p><strong>Status:</strong> ${data.status}</p>
    <p><strong>Job ID:</strong> ${data.jobID}</p>
`;
}
async function loadAllBookings(clientId, container) { //function to load all bookings
    if (!container) return; //if no container then stop

    container.textContent = "Loading bookings..."; //output loading message

    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}`); //send GET request to backend API and insert ID into URL

    if (!response.ok) { //if HTTP response not OK
        container.textContent = "Could not load bookings."; //output error message
        return; //stop
    }
    const bookings = await response.json(); //wait for response

    if (!Array.isArray(bookings) || bookings.length === 0) { //if no bookings
        container.textContent = "You have no bookings yet."; //output message
        return; //stop
    }

    const today = new Date(); //get current date to compare 

    const previous = bookings.filter(booking => { //filter bookings to get previous bookings only
        const date = new Date(booking.scheduledDate); //covert scheduled date to Date object
        const isPast = date < today; //check if booking date is before today
        const isCompleted = booking.status && booking.status.toLowerCase() === "completed"; //check if job status is completed
        return isPast || isCompleted; //return true if booking is in past or completed
    });

    if (previous.length === 0) { //if no previous bookings found
        container.textContent = "You have no previous bookings yet."; //output message
        return; //stop
    }

    //create rows for previous bookings table
    const rows = previous.map(booking => { 
        const dateStr = new Date(booking.scheduledDate).toLocaleDateString(); //covert date to readable string
        const timeSlot = booking.timeSlotPm ? "PM" : "AM"; // translate boolean to AM/PM
        const price = booking.estPrice != null ? `�${Number(booking.estPrice).toFixed(2)}` : "-"; //format price or show dash if null
        return `
            <tr>
                <td>${booking.jobID}</td>
                <td>${booking.serviceName}</td>
                <td>${dateStr} (${timeSlot})</td>
                <td>${booking.status}</td>
                <td>${price}</td>

            </tr>
        `;
    }).join(""); //join all table rows into single string

    if (!rows) { //if no rows created
        container.textContent = "You have no previous bookings yet."; //output message
        return; //stop
    }

    //insert HTML table with previous bookings
    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Quote (�)</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}