﻿namespace Neaproject.Dtos
{
    public class ClientUpdate
    {
        public string? Email { get; set; }
        public string? PhoneNum { get; set; }
        public string? Address { get; set; }
        public string? Postcode { get; set; }
        public string? Password { get; set; }
    }
}
