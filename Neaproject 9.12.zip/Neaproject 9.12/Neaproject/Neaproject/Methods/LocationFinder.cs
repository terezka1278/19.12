﻿using System;
using System.Collections.Generic;
namespace Neaproject.Methods
{
    public class LocationFinder
    {
        private static readonly Dictionary<string, string> PostcodeRegions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {

        };
        public static string GetRegion(string postcode)
        {
            if (string.IsNullOrWhiteSpace(postcode))
                return "Unknown";

            string trimmed = postcode.Replace("", "").ToUpper();

            if (trimmed.Length >= 2)
            {
                string letters2 = trimmed.Substring(0, 2);
                if (PostcodeRegions.ContainsKey(letters2))
                    return PostcodeRegions[letters2];
            }

            string letters1 = trimmed.Substring(0, 1);
            if (PostcodeRegions.ContainsKey(letters1))
                return PostcodeRegions[letters1];

            return "Unknown";
        }
    }
}
