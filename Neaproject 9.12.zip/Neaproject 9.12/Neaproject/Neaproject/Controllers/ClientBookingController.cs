﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Dtos;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client-bookings")]
    public class ClientBookingsController : ControllerBase
    {
        private readonly SqliteDataAccess _db;

        public ClientBookingsController(SqliteDataAccess db)
        {
            _db = db; //database access
        }

        [HttpGet("{clientId}")] //get all bookings
        public ActionResult<IEnumerable<ClientBooking>> GetAllBookings(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message
            var bookings = _db.GetBookingsForClient(clientId); //fetch al bookings for this client
            return Ok(bookings); // return booking list
        }

        [HttpGet("{clientId}/next")]  //get upcoming bookings
        public ActionResult<NextBooking> GetNextBooking(string clientId) 
        {
            if (string.IsNullOrWhiteSpace(clientId)) //
                return BadRequest("ClientId is required.");
            var booking = _db.GetNextBookingForClient(clientId); //get next booking
            if (booking == null || !booking.HasBooking) //if no upcoming bookings
                return Ok(new NextBooking { HasBooking = false }); //output
            return Ok(booking); //return next booking
        }
   
        [HttpGet("{clientId}/quotes")] //get quotes for clients
        public ActionResult<IEnumerable<ClientQuote>> GetQuotes(string clientId) 
        {
            if (string.IsNullOrWhiteSpace(clientId)) //if cl
                return BadRequest("ClientId is required.");

            var quotes = _db.GetQuotesForClient(clientId);
            return Ok(quotes);
        }

        [HttpGet("{clientId}/invoices")] //get invoices for clients
        public ActionResult<IEnumerable<ClientInvoice>> GetInvoices(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) //check if id exists
                return BadRequest("ClientId is required."); //output error message

            var invoices = _db.GetInvoicesForClient(clientId); //get all invoices
            return Ok(invoices); // return invoice list
        }
    }
}
