﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Dtos;
using Neaproject.Methods;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

//TODO: validation
namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/booking")]
    public class BookingController : ControllerBase
    {
        private readonly SqliteDataAccess _db; 
        public BookingController(SqliteDataAccess db) 
        {
            _db = db; //database access
        }

        [HttpPost("step1")] //STEP 1 (create job)
        public IActionResult Step1([FromBody] BookingStep1Request model) //model used to get data from front end
        {
            if (model == null) //if no data sent
                return BadRequest(new { message = "No data sent." }); //return bad request
            
            using (var conn = _db.GetConnection()) //get database connection
            {
                conn.Open(); //open connection
                using (var tx = conn.BeginTransaction()) //begin transaction
                {
                    string clientIdToUse; //variable to hold client ID

                    if (!string.IsNullOrWhiteSpace(model.ClientId)) //if user is logged in
                    {
                        using (var cmd = new SQLiteCommand( //check if client ID and email match
                            "SELECT Email FROM Clients WHERE ClientID = @ClientID;", conn, tx)) //SQL command to get email by client ID
                        {
                            cmd.Parameters.AddWithValue("@ClientID", model.ClientId); //add parameter to command
                            var emailInDb = cmd.ExecuteScalar() as string; //execute command and get email

                            if (emailInDb == null) //if no email found
                                return BadRequest(new { message = "Login invalid.", requiresLogin = true }); //output error message
                            if (!string.Equals(emailInDb, model.Email.Trim(), StringComparison.OrdinalIgnoreCase)) //if email does not match
                                return BadRequest(new { message = "Email not correct.", requiresLogin = true }); //output error message
                            clientIdToUse = model.ClientId; //set client ID to use
                        }
                    }
                    else
                    {
                        using (var checkCmd = new SQLiteCommand( //check if account exists
                            "SELECT ClientID FROM Clients WHERE Email = @Email;", conn, tx)) //get clientID by email
                        {
                            checkCmd.Parameters.AddWithValue("@Email", model.Email); //add email parameter
                            var exists = checkCmd.ExecuteScalar(); //execute command
                            if (exists != null) //if account exists
                                return BadRequest(new { message = "Account exists. Please log in.", requiresLogin = true }); //output error message
                            return BadRequest(new { message = "No account found. Please create one.", requiresAccount = true }); //output error message
                        }
                    }
                    string jobId = Guid.NewGuid().ToString(); //generate new job ID

                    using (var insertJob = new SQLiteCommand(@" 
                        INSERT INTO Jobs (JobID, ClientID, ServiceID, DateStarted, DateFinished, Status, Summary, NumOfPoints)
                        VALUES (@JobID, @ClientID, @ServiceID, NULL, NULL, 'Not Started', @Summary, @NumOfPoints);
                    ", conn, tx)) //insert new job into database
                    {
                        insertJob.Parameters.AddWithValue("@JobID", jobId); //add job ID 
                        insertJob.Parameters.AddWithValue("@ClientID", clientIdToUse); //   add client ID 
                        insertJob.Parameters.AddWithValue("@ServiceID", model.Service); //add service ID 
                        insertJob.Parameters.AddWithValue("@Summary", model.Summary); //add summary 
                        insertJob.Parameters.AddWithValue("@NumOfPoints", model.Points); //add points 
                        insertJob.ExecuteNonQuery();
                    }
                    tx.Commit(); //commit transaction
                    return Ok(new { clientId = clientIdToUse, jobId }); //return client ID and job ID
                }
                }
            }
   
        [HttpPost("step2")] //STEP 2 (find available slots)
        public IActionResult Step2([FromBody] BookingStep2Request model) //model used to get data from front end
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobId)) //if no data sent
                return BadRequest(new { message = "Invalid step 2 data." }); //output error message
            if (model.Days == null || model.Days.Count == 0) //if no days selected
                return BadRequest(new { message = "Select at least one day." }); //output error message

            var days = new List<DayOfWeek>(); //list to hold selected days
            foreach (string d in model.Days) //loop through selected days
                if (Enum.TryParse(d, true, out DayOfWeek result)) 
                    days.Add(result); //add valid days to list

            var finder = new FindAvailableSlots(_db); //create instance of FindAvailableSlots
            var available = finder.FindAvailableDates(days, 21); //find available dates within 21 days

            return Ok(new { jobId = model.JobId, suggestedDates = available }); //return job ID and available dates
        }

        [HttpPost("step2/confirm")] //STEP 2 CONFIRM (confirm booking)
        public IActionResult ConfirmStep2([FromBody] BookingStep2ConfirmRequest model) //model used to get data from front end
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobId) || 
                string.IsNullOrWhiteSpace(model.SelectedDate)) //if no data sent
                return BadRequest(new { message = "Invalid confirmation data." }); //output error message
            if (!DateTime.TryParse(model.SelectedDate, out var date)) 
                return BadRequest(new { message = "Invalid date format." }); //output error message

            using (var conn = _db.GetConnection()) //get database connection
            {
                conn.Open(); //open connection
                bool amTaken = false; //variable to track slot availability
                bool pmTaken = false; //variable to track slot availability

                using (var cmd = new SQLiteCommand( //check existing bookings
                    @"SELECT TimeSlot FROM Appointments WHERE ScheduledDate = @Date;", conn)) //get time slot
                {
                    cmd.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd")); //match date
                    using (var r = cmd.ExecuteReader()) 
                    {
                        while (r.Read())
                        {
                            int slot = r.GetInt32(0); //timeslot (1=am, 0=pm)
                            if (slot == 1) amTaken = true; //mark am taken
                            else pmTaken = true; //mark pm taken
                        }
                    }
                }
                int slotToBook = 
                    !amTaken ? 1 :
                    !pmTaken ? 0 :
                    throw new Exception("Both slots full"); // if both taken output error

                // INSERT appointment
                using (var insert = new SQLiteCommand(
                    @"INSERT INTO Appointments (AppointmentID, JobID, ScheduledDate, TimeSlot)
                        VALUES (@AID, @JID, @Date, @Slot);", conn))
                {
                    insert.Parameters.AddWithValue("@AID", Guid.NewGuid().ToString()); //new appointment
                    insert.Parameters.AddWithValue("@JID", model.JobId); //link job
                    insert.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd")); //store date
                    insert.Parameters.AddWithValue("@Slot", slotToBook);  // store time slot
                    insert.ExecuteNonQuery(); //run INSERT
                }

                // UPDATE job status
                using (var update = new SQLiteCommand( 
                    @"UPDATE Jobs SET Status='Booked' WHERE JobID=@JID;", conn))
                {
                    update.Parameters.AddWithValue("@JID", model.JobId); //job to update
                    update.ExecuteNonQuery(); //run UPDATE
                }
                return Ok(new 
                {
                    message = "Booking confirmed.", 
                    jobId = model.JobId,
                    selectedDate = date.ToString("yyyy-MM-dd"),
                    timeSlot = slotToBook == 1 ? "AM" : "PM" //convert slot number to text
                });
            }
            }
        }
    }
