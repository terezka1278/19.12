﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using System.Collections.Generic;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/business/documents")]
    public class BusinessDocumentsController : ControllerBase
    {
        private readonly SqliteDataAccess _db;

        public BusinessDocumentsController(SqliteDataAccess db)
        {
            _db = db;
        }

        // ===================== GET ALL QUOTES =====================
        [HttpGet("quotes")]
        public ActionResult<IEnumerable<ClientQuote>> GetAllQuotes()
        {
            var quotes = _db.GetAllQuotes();
            return Ok(quotes);
        }

        // ===================== CREATE QUOTE (AUTO CALCULATED) =====================
        [HttpPost("quotes/create")]
        public IActionResult CreateQuote([FromBody] string jobId)
        {
            if (string.IsNullOrWhiteSpace(jobId))
                return BadRequest("Invalid job ID.");

            // 1. Find service linked to job
            string serviceId = _db.GetServiceIdForJob(jobId);

            // 2. Start with base service price
            decimal total = _db.GetServiceBasePrice(serviceId);

            // 3. Get default supplies for service
            var supplies = _db.GetServiceSupplies(serviceId);

            string quoteId = Guid.NewGuid().ToString();

            // 4. Calculate supply costs and store quote items
            foreach (var s in supplies)
            {
                decimal lineCost = s.Quantity * s.UnitPrice;
                total += lineCost;

                _db.InsertQuoteItem(
                    Guid.NewGuid().ToString(),
                    quoteId,
                    s.SupplyID,
                    s.Quantity,
                    s.UnitPrice
                );
            }

            // 5. Insert final quote (calculated price only)
            _db.InsertQuote(
                quoteId,
                jobId,
                total
            );

            // 6. Update job status
            _db.UpdateJobStatus(jobId, "Quote Submitted");

            return Ok(new
            {
                message = "Quote created successfully.",
                quoteId,
                total
            });
        }

        // ===================== GET ALL INVOICES =====================
        [HttpGet("invoices")]
        public ActionResult<IEnumerable<ClientInvoice>> GetAllInvoices()
        {
            var invoices = _db.GetAllInvoices();
            return Ok(invoices);
        }

        // ===================== CREATE INVOICE (UNCHANGED) =====================
        [HttpPost("invoices/create")]
        public IActionResult CreateInvoice([FromBody] BusinessInvoiceCreateRequest model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobID))
                return BadRequest(new { message = "Invalid invoice data." });

            decimal totalPrice =
                (model.MaterialCost * model.MaterialQty) + model.LabourCost;

            string invoiceId = Guid.NewGuid().ToString();

            _db.CreateInvoice(
                invoiceId,
                model.JobID,
                model.MaterialCost,
                model.MaterialQty,
                model.LabourCost,
                totalPrice
            );

            _db.UpdateJobStatus(model.JobID, "Invoiced");

            return Ok(new
            {
                message = "Invoice created successfully.",
                invoiceId,
                total = totalPrice
            });
        }
    }
}
