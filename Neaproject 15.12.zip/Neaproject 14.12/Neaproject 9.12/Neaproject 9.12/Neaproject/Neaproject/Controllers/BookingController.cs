﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using Neaproject.Methods;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

//TODO: validation
namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/booking")]
    public class BookingController : ControllerBase
    {
        private readonly SqliteDataAccess _db;
        public BookingController(SqliteDataAccess db)
        {
            _db = db; //database access
        }

        [HttpPost("step1")] //STEP 1 (create job)
        public IActionResult Step1([FromBody] BookingStep1Request model) //model used to get data from front end
        {
            if (model == null) //if no data sent
                return BadRequest(new { message = "No data sent." }); //return bad request

            using (var conn = _db.GetConnection()) //get database connection
            {
                conn.Open(); //open connection
                using (var tx = conn.BeginTransaction()) //begin transaction
                {
                    string? clientIdToUse = model.ClientId; //variable to hold client ID

                    if (!string.IsNullOrWhiteSpace(model.ClientId)) //if user is logged in
                    {
                        using (var cmd = new SQLiteCommand( //check if client ID and email match
                            "SELECT Email FROM Clients WHERE ClientID = @ClientID;", conn, tx)) //SQL command to get email by client ID
                        {
                            cmd.Parameters.AddWithValue("@ClientID", model.ClientId); //add parameter to command
                            object result = cmd.ExecuteScalar();
                            string? emailInDb;

                            if (result == null)
                            {
                                emailInDb = null;
                            }
                            else
                            {
                                emailInDb = result.ToString();
                            } //execute command and get email

                            if (emailInDb == null) //if no email found
                                return BadRequest(new { message = "Login invalid.", requiresLogin = true }); //output error message
                            if (!string.Equals(emailInDb, model.Email.Trim(), StringComparison.OrdinalIgnoreCase)) //if email does not match
                                return BadRequest(new { message = "Email not correct.", requiresLogin = true }); //output error message
                            clientIdToUse = model.ClientId; //set client ID to use
                        }
                    }
                    else
                    {
                        using (var checkCmd = new SQLiteCommand( //check if account exists
                            "SELECT ClientID FROM Clients WHERE Email = @Email;", conn, tx)) //get clientID by email
                        {
                            checkCmd.Parameters.AddWithValue("@Email", model.Email); //add email parameter
                            var exists = checkCmd.ExecuteScalar(); //execute command
                            if (exists != null) //if account exists
                                return BadRequest(new { message = "Account exists. Please log in.", requiresLogin = true }); //output error message
                            return BadRequest(new { message = "No account found. Please create one.", requiresAccount = true }); //output error message
                        }
                    }
                    string jobId = Guid.NewGuid().ToString(); //generate new job ID
                    string location = LocationFinder.GetRegion(model.Postcode);

                    using(var insertJob = new SQLiteCommand(@"
                        INSERT INTO Jobs (
                            JobID, ClientID, ServiceID, DateStarted, DateFinished, Status, Summary, NumOfPoints, Location
                        )
                        VALUES (
                            @JobID, @ClientID, @ServiceID, NULL, NULL, 'Not Started', @Summary, @NumOfPoints, @Location
                        );
                    ", conn, tx)) //insert new job into database
                    {
                        insertJob.Parameters.AddWithValue("@JobID", jobId); //add job ID 
                        insertJob.Parameters.AddWithValue("@ClientID", clientIdToUse); //   add client ID 
                        insertJob.Parameters.AddWithValue("@ServiceID", model.Service); //add service ID 
                        insertJob.Parameters.AddWithValue("@Summary", model.Summary); //add summary 
                        insertJob.Parameters.AddWithValue("@NumOfPoints", model.Points); //add points 
                        insertJob.Parameters.AddWithValue("@Location", location); //add location
                        insertJob.ExecuteNonQuery();
                    }
                    
                    tx.Commit(); //commit transaction
                    return Ok(new { clientId = clientIdToUse, jobId }); //return client ID and job ID
                }
            }
        }

        [HttpPost("step2")] //STEP 2 (find available slots)
        public IActionResult Step2([FromBody] BookingStep2Request model) //model used to get data from front end
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobId)) //if no data sent
                return BadRequest(new { message = "Invalid step 2 data." }); //output error message
            if (model.Days == null || model.Days.Count == 0) //if no days selected
                return BadRequest(new { message = "Select at least one day." }); //output error message

            var days = new List<DayOfWeek>(); //list to hold selected days
            foreach (string d in model.Days) //loop through selected days
                if (Enum.TryParse(d, true, out DayOfWeek result))
                    days.Add(result); //add valid days to list

            var finder = new FindAvailableSlots(_db); //create instance of FindAvailableSlots
            var available = finder.FindAvailableDates(model.JobId, days, 62, 5); //find available dates within 2 months

            return Ok(new { jobId = model.JobId, suggestedDates = available }); //return job ID and available dates
        }

        [HttpPost("step2/confirm")]
        public IActionResult ConfirmStep2([FromBody] BookingStep2ConfirmRequest model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.JobId) ||
                string.IsNullOrWhiteSpace(model.SelectedDate) ||
                string.IsNullOrWhiteSpace(model.SelectedSlot)) //check all fields
            {
                return BadRequest(new { message = "Invalid confirmation data." }); //output error message
            }

            if (!DateTime.TryParse(model.SelectedDate, out var date)) //try to convert date
            {
                return BadRequest(new { message = "Invalid date format." }); //output error message
            }

            using (var conn = _db.GetConnection()) //get database connection
            {
                conn.Open(); //open connection

                bool amTaken = false; //track if AM slot is taken
                bool pmTaken = false; //track if PM slot is taken

                // get the region for the job being booked
                string? jobLocation;
                using (var getLoc = new SQLiteCommand(
                    "SELECT Location FROM Jobs WHERE JobID = @JID;", conn))
                {
                    getLoc.Parameters.AddWithValue("@JID", model.JobId);
                    object locResult = getLoc.ExecuteScalar(); //run query

                    if (locResult == null) //if no location found
                    {
                        jobLocation = null;
                    }
                    else
                    {
                        jobLocation = locResult.ToString(); //convert to string
                    }
                }

                // check existing appointments ON THAT DATE + compare regions
                using (var cmd = new SQLiteCommand(
                    @"SELECT A.TimeSlot, J.Location 
              FROM Appointments A
              JOIN Jobs J ON A.JobID = J.JobID
              WHERE ScheduledDate = @Date;", conn))
                {
                    cmd.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd"));

                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            int slot = r.GetInt32(0); //1 = AM, 0 = PM
                            string existingLocation = r.GetString(1); //location of that job

                            // region conflict = booking not allowed
                            if (!string.Equals(existingLocation, jobLocation, StringComparison.OrdinalIgnoreCase))
                            {
                                return BadRequest(new
                                {
                                    message = "Cannot book this date because another job that day is in a different region.",
                                    regionConflict = true
                                });
                            }

                            if (slot == 1)
                            {
                                amTaken = true; //AM already booked
                            }
                            else
                            {
                                pmTaken = true; //PM already booked
                            }
                        }
                    }
                }

                //make sure the chosen slot is still free
                if (model.SelectedSlot == "AM" && amTaken)
                {
                    return BadRequest(new { message = "AM slot already booked for this date." });
                }
                if (model.SelectedSlot == "PM" && pmTaken)
                {
                    return BadRequest(new { message = "PM slot already booked for this date." });
                }

                int slotToBook; //slot chosen by user

                if (model.SelectedSlot == "AM") //if user chose AM
                {
                    slotToBook = 1; //AM slot
                }
                else //otherwise PM
                {
                    slotToBook = 0; //PM slot
                }

                // INSERT appointment
                using (var insert = new SQLiteCommand(
                    @"INSERT INTO Appointments (AppointmentID, JobID, ScheduledDate, TimeSlot)
              VALUES (@AID, @JID, @Date, @Slot);", conn))
                {
                    insert.Parameters.AddWithValue("@AID", Guid.NewGuid().ToString()); //new appointment ID
                    insert.Parameters.AddWithValue("@JID", model.JobId); //job ID
                    insert.Parameters.AddWithValue("@Date", date.ToString("yyyy-MM-dd")); //date
                    insert.Parameters.AddWithValue("@Slot", slotToBook); //AM or PM slot
                    insert.ExecuteNonQuery(); //run insert
                }

                // update status
                using (var update = new SQLiteCommand(
                    @"UPDATE Jobs SET Status='Booked' WHERE JobID=@JID;", conn))
                {
                    update.Parameters.AddWithValue("@JID", model.JobId);
                    update.ExecuteNonQuery();
                }

                string slotText;
                if (slotToBook == 1)
                {
                    slotText = "AM";
                }
                else
                {
                    slotText = "PM";
                }

                return Ok(new
                {
                    message = "Booking confirmed.",
                    jobId = model.JobId,
                    selectedDate = date.ToString("yyyy-MM-dd"),
                    timeSlot = slotText
                });
            }
        }

    }

}
