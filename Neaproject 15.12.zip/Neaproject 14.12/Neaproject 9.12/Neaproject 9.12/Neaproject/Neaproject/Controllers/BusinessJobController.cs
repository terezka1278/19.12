﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.DataObjects;
using Neaproject.Models;
using System.Collections.Generic;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/business/jobs")] //
    public class BusinessJobsController : ControllerBase
    {
        private readonly SqliteDataAccess _db; 

        public BusinessJobsController(SqliteDataAccess db) 
        {
            _db = db; //database access
        }

        [HttpGet] //get request
        public ActionResult<IEnumerable<Job>> GetAll() //return list of jobs
        {
            var jobs = _db.GetAllJobs(); //call database method
            return Ok(jobs); // return list
        }

        [HttpPut("{jobId}/complete")] //url pattern
        public IActionResult MarkCompleted(string jobId) // method to update job status
        {
            _db.MarkJobCompleted(jobId); // call database
            return NoContent(); // return HTTP
        }
    }
}
