﻿// ===============================
// Client Documents (Bookings)
// ===============================

// Holds the currently selected booking
let selectedJobId = null;

document.addEventListener("DOMContentLoaded", () => {

    console.log("client-documents.js loaded");

    // -------------------------------
    // Authentication check
    // -------------------------------
    const clientId = localStorage.getItem("clientID");

    if (!clientId) {
        window.location.href = "login.html";
        return;
    }

    // -------------------------------
    // Page elements
    // -------------------------------
    const manageOutput = document.getElementById("manage-output");
    const quotesOutput = document.getElementById("quotes-list");
    const invoicesOutput = document.getElementById("invoices-list");
    const cancelBtn = document.getElementById("cancel");

    // -------------------------------
    // Load all client data
    // -------------------------------
    loadClientBookings(clientId, manageOutput);
    loadClientQuotes(clientId, quotesOutput);
    loadClientInvoices(clientId, invoicesOutput);

    // -------------------------------
    // Cancel booking button
    // -------------------------------
    if (cancelBtn) {
        cancelBtn.addEventListener("click", async () => {

            if (!selectedJobId) {
                alert("Please select a booking first.");
                return;
            }

            if (!confirm("Are you sure you want to cancel this booking?\nThis action cannot be undone.")) {
                return;
            }

            const response = await fetch(`/api/client-bookings/${selectedJobId}`, {
                method: "DELETE"
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.message || "Failed to cancel booking.");
                return;
            }

            alert("Booking cancelled successfully.");
            location.reload();
        });
    }
});


// ===============================
// Load client bookings
// ===============================
async function loadClientBookings(clientId, container) {

    if (!container) return;

    container.textContent = "Loading bookings...";

    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}`);

    if (!response.ok) {
        container.textContent = "Could not load bookings.";
        return;
    }

    const bookings = await response.json();

    if (!Array.isArray(bookings) || bookings.length === 0) {
        container.textContent = "You have no bookings.";
        return;
    }

    const rows = bookings.map(b => `
        <tr class="booking-row"
            onclick="selectBooking('${b.jobID}', this)">
            <td>${b.jobID}</td>
            <td>${b.serviceName}</td>
            <td>${b.status}</td>
        </tr>
    `).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}


// ===============================
// Load client quotes
// ===============================
async function loadClientQuotes(clientId, container) {

    if (!container) return;

    container.textContent = "Loading quotes...";

    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}/quotes`);

    if (!response.ok) {
        container.textContent = "Could not load quotes.";
        return;
    }

    const quotes = await response.json();

    if (!Array.isArray(quotes) || quotes.length === 0) {
        container.textContent = "You currently have no quotes.";
        return;
    }

    const rows = quotes.map(q => {
        const statusText = q.accepted ? "Accepted" : "Pending";
        return `
            <tr>
                <td>${q.quoteID}</td>
                <td>${q.jobID}</td>
                <td>${q.serviceName}</td>
                <td>£${Number(q.estPrice).toFixed(2)}</td>
                <td>${q.estDuration} hrs</td>
                <td>${statusText}</td>
            </tr>
        `;
    }).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Quote ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Estimated Price</th>
                    <th>Estimated Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}


// ===============================
// Load client invoices
// ===============================
async function loadClientInvoices(clientId, container) {

    if (!container) return;

    container.textContent = "Loading invoices...";

    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}/invoices`);

    if (!response.ok) {
        container.textContent = "Could not load invoices.";
        return;
    }

    const invoices = await response.json();

    if (!Array.isArray(invoices) || invoices.length === 0) {
        container.textContent = "You currently have no invoices.";
        return;
    }

    const rows = invoices.map(i => `
        <tr>
            <td>${i.invoiceID}</td>
            <td>${i.jobID}</td>
            <td>${i.serviceName}</td>
            <td>£${Number(i.finalPrice).toFixed(2)}</td>
            <td>${i.paymentStatus}</td>
            <td>£${Number(i.depositPaid).toFixed(2)}</td>
        </tr>
    `).join("");

    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Final Price</th>
                    <th>Payment Status</th>
                    <th>Deposit Paid</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}


// ===============================
// Booking selection handler
// ===============================
function selectBooking(jobId, row) {

    selectedJobId = jobId;

    document.querySelectorAll(".booking-row")
        .forEach(r => r.classList.remove("selected"));

    row.classList.add("selected");

    console.log("Selected booking:", jobId);
}
