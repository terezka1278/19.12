﻿document.addEventListener("DOMContentLoaded", async () => {

    // Get selected job from previous page
    const jobId = localStorage.getItem("selectedJobId");

    if (!jobId) {
        alert("No booking selected.");
        return;
    }

    // -------------------------------
    // Load job + client details
    // -------------------------------
    const jobRes = await fetch(`/api/business/jobs/${jobId}`);

    if (!jobRes.ok) {
        alert("Failed to load job details.");
        return;
    }

    const job = await jobRes.json();

    // Autofill read-only fields
    document.getElementById("jobId").value = job.jobID;
    document.getElementById("clientId").value = job.clientID;
    document.getElementById("firstName").value = job.clientFirstName;
    document.getElementById("lastName").value = job.clientLastName;
    document.getElementById("phone").value = job.phoneNumber;
    document.getElementById("email").value = job.email;
    document.getElementById("postcode").value = job.postcode;
    document.getElementById("serviceName").value = job.serviceName;
    document.getElementById("timeEst").value = job.estDuration + " mins";

    // -------------------------------
    // Load default supplies (preview)
    // -------------------------------
    const supplyRes = await fetch(
        `/api/business/services/${job.serviceID}/supplies`
    );

    if (!supplyRes.ok) {
        alert("Failed to load supplies.");
        return;
    }

    const supplies = await supplyRes.json();
    const tableBody = document.getElementById("suppliesTable");

    supplies.forEach(s => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${s.supplyName}</td>
            <td>${s.supplyID}</td>
            <td>${s.quantity}</td>
        `;
        tableBody.appendChild(row);
    });

    // -------------------------------
    // Create quote (backend only)
    // -------------------------------
    document
        .getElementById("createQuoteBtn")
        .addEventListener("click", async () => {

            const res = await fetch(
                "/api/business/documents/quotes/create",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(jobId)
                }
            );

            const data = await res.json();

            if (!res.ok) {
                alert("Failed to create quote.");
                return;
            }

            document.getElementById("quoteTotal").textContent =
                "£" + Number(data.total).toFixed(2);
        });
});
