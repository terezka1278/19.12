﻿using System.Text;
using System.Security.Cryptography;
using System.Reflection.Metadata;

namespace Neaproject.Methods
{
    public class PasswordHasher
    {
        public static string Hash(string password)
        {
            using (var sha = SHA256.Create()) //create SHA-256 Hash
            {
                var bytes = Encoding.UTF8.GetBytes(password); //text to bytes
                var hash = sha.ComputeHash(bytes); //generate hash bytes
                return Convert.ToBase64String(hash); //hash bytes into readable base 64 string
            }
        }

        public static bool Verify(string rawPassword, string storedHash) //check iif password matched hashed password
        {
            string rawHash = Hash(rawPassword);
            bool match = false;
            if (rawHash == storedHash)  //if matches
            { 
                match = true; //return true
            }
            return match; //return if match or not
        }
    }
}
