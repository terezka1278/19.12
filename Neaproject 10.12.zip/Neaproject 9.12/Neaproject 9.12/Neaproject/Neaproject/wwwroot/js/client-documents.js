﻿document.addEventListener("DOMContentLoaded", () => { //runs only when HTML is fully loaded
    console.log("client-documents.js loaded"); //debugging log

    const clientId = localStorage.getItem("clientID"); //get client ID from local storage

    if (!clientId) { //if no client ID found
        window.location.href = "login.html"; //redirect to login
        return; //stop 
    }

    //get output containers
    const manageOutput = document.getElementById("manage-output"); //get manage output element
    const quotesOutput = document.getElementById("quote-output"); //get quote output element
    const invoicesOutput = document.getElementById("invoice-output"); //get invoice output element

    loadClientBookings(clientId, manageOutput); //load bookings
    loadClientQuotes(clientId, quotesOutput); //load quotes
    loadClientInvoices(clientId, invoicesOutput); //load invoices
});
async function loadClientQuotes(clientId, container) { //function to load client quotes
    if (!container) return; //if no container  then stop

    container.textContent = "Loading quotes..."; //output message
    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}/quotes`); //send GET request to backend API and insert ID into URL

    if (!response.ok) { //if HTTP response is not OK
        container.textContent = "Could not load quotes."; //output error message
        return; //stop
    }
    const quotes = await response.json(); //wait for response

    if (!Array.isArray(quotes) || quotes.length === 0) { // if user has no quotes
        container.textContent = "You currently have no quotes."; //output message
        return; //stop
    }

    //create table rows for each quote
    const rows = quotes.map(quotes => {
        const acceptedText = quotes.accepted ? "Accepted" : "Pending"; //convert boolean to text
        return `
            <tr>
                <td>${quotes.quoteID}</td>
                <td>${quotes.jobID}</td>
                <td>${quotes.serviceName}</td>
                <td>£${Number(quotes.estPrice).toFixed(2)}</td>
                <td>${quotes.estDuration} hrs</td>
                <td>${acceptedText}</td>
            </tr>
        `;
    }).join("");

    //insert HTML showing quotes table
    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Quote ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Estimated Price</th>
                    <th>Estimated Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}
async function loadClientInvoices(clientId, container) { //function to load client invoices
    if (!container) return; //if no container then stop
    container.textContent = "Loading invoices..."; //output loading message

    const response = await fetch(`/api/client-bookings/${encodeURIComponent(clientId)}/invoices`); //send GET request to backend API and insert ID into URL
    if (!response.ok) { //if HTTP response not OK
        container.textContent = "Could not load invoices."; //output error message
        return; //stop
    }

    const invoices = await response.json(); //wait for response

    if (!Array.isArray(invoices) || invoices.length === 0) { //if no invoices
        container.textContent = "You currently have no invoices."; //output message
        return; //stop
    }

    //create table rows for each invoice
    const rows = invoices.map(invoices => {
        return `
            <tr>
                <td>${invoices.invoiceID}</td>
                <td>${invoices.jobID}</td>
                <td>${invoices.serviceName}</td>
                <td>£${Number(invoices.finalPrice).toFixed(2)}</td>
                <td>${invoices.paymentStatus}</td>
                <td>£${Number(invoices.depositPaid).toFixed(2)}</td>
            </tr>
        `;
    }).join("");

    //insert HTML showing invoices table
    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Final Price</th>
                    <th>Payment Status</th>
                    <th>Deposit Paid</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}