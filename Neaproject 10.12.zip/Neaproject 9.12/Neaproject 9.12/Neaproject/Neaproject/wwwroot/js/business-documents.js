﻿document.addEventListener("DOMContentLoaded", () => { //run only when HTML is fully loaded
    console.log("business-documents.js loaded"); //debugging log
    loadAllQuotes(); //load all quotes for business
    loadAllInvoices(); //load all invoices for business
});

async function loadAllQuotes() { //function to load all quotes for business
    const container = document.getElementById("quote-output"); //get quote output element
    container.textContent = "Loading quotes..."; //show loading message
    const res = await fetch("/api/business/documents/quotes"); //fetch quotes from backend API

    if (!res.ok) { //if HTTP response not OK
        container.textContent = "Could not load quotes."; //output error message
        return; //stop
    }
    const quotes = await res.json(); //wait for response JSON

    if (!Array.isArray(quotes) || quotes.length === 0) { //if no quotes
        container.textContent = "There are currently no quotes."; //output message
        return; //stop
    }

    //create table rows for each quote
    const rows = quotes.map(q => { 
        const acceptedText = q.accepted ? "Accepted" : "Pending"; //set accepted status text
        return `
            <tr>
                <td>${q.quoteID}</td>
                <td>${q.jobID}</td>
                <td>${q.serviceName}</td>
                <td>£${Number(q.estPrice).toFixed(2)}</td>
                <td>${q.estDuration} hrs</td>
                <td>${acceptedText}</td>
            </tr>
        `; //return row string
    }).join(""); //join all rows into single string

    //insery HTML table into container
    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Quote ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Estimated Price</th>
                    <th>Estimated Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}

async function loadAllInvoices() { //function to load all invoices for business
    const container = document.getElementById("invoice-output"); //get invoice output element
    container.textContent = "Loading invoices..."; //output loading message

    const res = await fetch("/api/business/documents/invoices"); //fetch invoices from backend API
    if (!res.ok) { //if HTTP response not OK
        container.textContent = "Could not load invoices."; //output error message
        return; //stop
    }

    const invoices = await res.json(); //wait for response JSON
    if (!Array.isArray(invoices) || invoices.length === 0) { //if no invoices
        container.textContent = "There are currently no invoices."; //output message
        return; //stop
    }

    //create table rows for each invoice
    const rows = invoices.map(inv => ` 
        <tr>
            <td>${inv.invoiceID}</td>
            <td>${inv.jobID}</td>
            <td>${inv.serviceName}</td>
            <td>£${Number(inv.finalPrice).toFixed(2)}</td>
            <td>${inv.paymentStatus}</td>
            <td>£${Number(inv.depositPaid).toFixed(2)}</td>
        </tr>
    `).join(""); //join all rows into single string

    //insert HTML table into container
    container.innerHTML = `
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice ID</th>
                    <th>Job ID</th>
                    <th>Service</th>
                    <th>Final Price</th>
                    <th>Payment Status</th>
                    <th>Deposit Paid</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}