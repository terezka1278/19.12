﻿document.addEventListener("DOMContentLoaded", () => { //runs only when HTML is fully loaded
    console.log("business-jobs.js loaded"); //debugging log
    loadAllJobs(); //call function to load jobs
});

async function loadAllJobs() { //function to load and display jobs
    const container = document.getElementById("manage-output"); //get output element
    if (!container) { //if no element found
        console.error("#manage-output not found"); //debugging lof
        return; //stop
    }
    container.innerHTML = "<p>Loading bookings...</p>"; //show loading message
    
    const response = await fetch("/api/business/jobs"); //send GET request to backend API and insert ID into URL
    if (!response.ok) { //if HTTP response not OK
        container.innerHTML = "<p>Failed to load bookings.</p>"; //output error message
        return; //stop
    }

    const jobs = await response.json(); //wait for response

    if (!jobs || jobs.length === 0) { //if no bookings
        container.innerHTML = "<p>No bookings found.</p>"; //output message
        return; //stop
    }

    const table = document.createElement("table"); //create table element
    table.classList.add("jobs-table");  // add css class for styling

    const thead = document.createElement("thead"); //create table header
    thead.innerHTML = `
        <tr>
            <th>Job ID</th>
            <th>Date</th>
            <th>Client</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    `;
    table.appendChild(thead); //add header to table
    const tbody = document.createElement("tbody"); //create table body

    jobs.forEach(job => { //loop through all jobs 
        const tr = document.createElement("tr"); //create table row
        const dateText = new Date(job.scheduledDate).toLocaleDateString(undefined, { //format date
            year: "numeric",
            month: "short",
            day: "numeric"
        });

        //fill in row with job details 
        tr.innerHTML = `
            <td>${job.jobID}</td>
            <td>${dateText}</td>
            <td>${job.clientName}</td>
            <td class="status-cell">${job.status}</td>
            <td></td>
        `;
        const actionTd = tr.lastElementChild; // get the action cell
        const btn = document.createElement("button"); //create button
        btn.type = "button"; //set button type
        btn.textContent = "Mark Completed"; //set button text
        btn.classList.add("button"); //add css class for styling

        if (job.status === "Completed") { //if already completed
            btn.disabled = true; //disable button
        }

        btn.addEventListener("click", () => markCompleted(job.jobID, tr)); //when clicked call markCompleted function
        actionTd.appendChild(btn); // add button to action cell
        tbody.appendChild(tr); //add row to table body
    });

    table.appendChild(tbody); //add body to table
    container.innerHTML = ""; //clear loading message
    container.appendChild(table); //add table to output element
    }

async function markCompleted(jobId, row) { //mark completed function
    if (!confirm(`Mark job ${jobId} as Completed?`)) return; //ask user for confirmation
    
    const response = await fetch(`/api/business/jobs/${encodeURIComponent(jobId)}/complete`, { //send PUT request to backend API
        method: "PUT"
    });

    if (!response.ok) { //if HTTP response not OK
        alert("Failed to update job."); //show error message
        return; //stop
    }

    const statusCell = row.querySelector(".status-cell"); //get status cell in the row
    if (statusCell) statusCell.textContent = "Completed"; //update status text

    const button = row.querySelector("button"); //get button in the row
    if (button) button.disabled = true; //disable button
}