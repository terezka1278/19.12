﻿document.addEventListener("DOMContentLoaded", () => { //run only when HTML is fully loaded
    console.log("business-home.js loaded"); //debugging log
    loadDashboard(); //load dashboard data
});

async function loadDashboard() { //function to load dashboard data
    const todayList = document.getElementById("JobsToday"); //get today's jobs list element
    const weekTable = document.getElementById("week-calendar"); //get week calendar table element
    const monthTable = document.getElementById("month-calendar"); //get month calendar table element

    const todayTbody = weekTable.querySelector("tbody"); //get tbody of week table
    const monthTbody = monthTable.querySelector("tbody"); //get tbody of month table
    todayList.innerHTML = "<li>Loading...</li>"; //show loading message
    todayTbody.innerHTML = ""; //clear week table
    monthTbody.innerHTML = ""; //clear month table

    const response = await fetch("/api/business/jobs"); //send GET request to backend API for jobs
    if (!response.ok) { //if HTTP response not OK
        todayList.innerHTML = "<li>Failed to load jobs.</li>"; //output error message
        return; //stop
    }

    const rawJobs = await response.json(); //wait for response
    const jobs = rawJobs.map(normaliseJob); //normalise job data
    renderToday(jobs, todayList); //render today's jobs
    renderWeek(jobs, weekTable); //render week view
    renderMonth(jobs, monthTable); //render month view
}

function normaliseJob(raw) { //function to normalise job data from API (nneded as inconsistent naming that i need to change later))
    const jobId = raw.jobId || raw.JobID || raw.jobID; //handle different possible namings
    const clientName = raw.clientName || raw.ClientName; 
    const scheduledDateStr = raw.scheduledDate || raw.ScheduledDate;
    const status = raw.status || raw.Status;
    const serviceName = raw.serviceName || raw.ServiceName;  
    const address = raw.address || raw.Address;              
    const postcode = raw.postcode || raw.Postcode;            
    const dateObj = scheduledDateStr ? new Date(scheduledDateStr) : null;

    return {
        jobId,
        clientName,
        status,
        dateObj,
        serviceName,
        address,
        postcode
    };
}

function isSameDate(d1, d2) {
    return d1.getFullYear() === d2.getFullYear() &&
        d1.getMonth() === d2.getMonth() &&
        d1.getDate() === d2.getDate();
}

function renderToday(jobs, listEl) { //function to render today's jobs
    const today = new Date(); //get today's date
    listEl.innerHTML = ""; //clear existing list

    const todaysJobs = jobs.filter(j => j.dateObj && isSameDate(j.dateObj, today)); //filter jobs for today
    if (todaysJobs.length === 0) { //if no jobs today
        listEl.innerHTML = "<li>No jobs scheduled for today.</li>"; //output message
        return; //stop
    }

    todaysJobs.forEach(job => { //loop through today's jobs
        const li = document.createElement("li"); //create list item
        li.textContent = `${job.clientName} – ${job.serviceName} – ${job.address} (${job.status})`; //set text content
        listEl.appendChild(li); //add list item to list
    });
}

function renderWeek(jobs, weekTable) { //function to render week view
    const tbody = weekTable.querySelector("tbody"); //get tbody of week table
    tbody.innerHTML = ""; //clear existing rows
    const row = document.createElement("tr"); //create row element
    const today = new Date(); //get today's date
    const day = today.getDay(); // 0=Sun,1=Mon,...
    const diffToMonday = (day === 0 ? -6 : 1 - day); // if Sunday, go back 6 days
    const monday = new Date(today); //copy today’s date
    monday.setDate(today.getDate() + diffToMonday); //set date to Monday of current week

    for (let i = 0; i < 5; i++) { //loop through Monday to Friday
        const current = new Date(monday); //copy Monday’s date
        current.setDate(monday.getDate() + i); //add i days to get current day

        const td = document.createElement("td"); //create table cell
        const header = document.createElement("div"); //create header div
        header.classList.add("day-header"); //add class for styling
        header.textContent = current.toLocaleDateString(undefined, { //format date
            weekday: "short",
            day: "numeric",
            month: "short"
        });
        td.appendChild(header); //add header to cell

        const dayJobs = jobs.filter(j => j.dateObj && isSameDate(j.dateObj, current));

        if (dayJobs.length === 0) {
            const p = document.createElement("p");
            p.classList.add("no-jobs");
            p.textContent = "No jobs";
            td.appendChild(p);
        } else {
            dayJobs.forEach(job => {
                const p = document.createElement("p");
                p.classList.add("job-item");
                p.textContent =
                    `${job.clientName} – ${job.serviceName} – ${job.address} (${job.status})`;

                td.appendChild(p);
            });

        //let foundJobs = false; //check if jobs found for the day
       // for (let j = 0; j < jobs.length; j++) { //loop through jobs
           // const job = jobs[j]; //get job
            //cheks is job date matches current date
            //if (
                //job.dateObj &&
                //job.dateObj.getDate() === currentDate.getDate() &&
                //job.dateObj.getMonth() === currentDate.getMonth() &&
               // job.dateObj.getFullYear() === currentDate.getFullYear())
           // {
              //  const p = document.createElement("p"); //create paragraph element
               // p.className = "job-item"; //add class for styling
               // p.textContent = `${job.clientName} – ${job.serviceName} – ${job.address} (${job.status})`; //set text content
               // cell.appendChild(p); //add paragraph to cell
               // foundJobs = true; //mark that jobs were found
            //}
        //}
       // if (!foundJobs) { //if no jobs found for the day
           // const p = document.createElement("p"); //create paragraph element
           // p.className = "no-jobs"; //add class for styling
         //   p.textContent = "No jobs"; //set text content
            //cell.appendChild(p); //add paragraph to cell
        }
        row.appendChild(cell); //add cell to row
    }
    tbody.appendChild(row); //add row to week tbody
}

function renderMonth(jobs, monthTable) { //function to render month view
    const tbody = monthTable.querySelector("tbody"); //get tbody of month table
    tbody.innerHTML = ""; //clear existing rows

    const now = new Date(); // get current date
    const year = now.getFullYear(); // get current year
    const month = now.getMonth(); // get current month (0-11)
    const firstDay = new Date(year, month, 1); // first day of the month
    const startOffset = (firstDay.getDay() + 6) % 7; // shift so Monday is 0
    const daysInMonth = new Date(year, month + 1, 0).getDate(); // get number of days in month
    let currentDay = 1 - startOffset; // might be 0 or negative to fill week start

    for (let week = 0; week < 6; week++) { //loop through weeks
        const row = document.createElement("tr"); //create table row
        for (let d = 0; d < 7; d++) { //loop through days of the week
            const cell = document.createElement("td"); //create table cell

            if (currentDay < 1 || currentDay > daysInMonth) { //empty cell
                cell.classList.add("empty-day"); // add class for styling empty cells
            } else {
                const date = new Date(year, month, currentDay); //create date object for current day
                const label = document.createElement("div"); //create date label
                label.className = "date-label"; //add class for styling
                label.textContent = currentDay; //set date number
                cell.appendChild(label); //add date label to cell

                // go through all jobs to find matches
                for (let j = 0; j < jobs.length; j++) { //loop through jobs
                    const job = jobs[j]; //get job
                    //checks if job date matches current date
                    if (job.dateObj &&
                        job.dateObj.getDate() === date.getDate() &&
                        job.dateObj.getMonth() === date.getMonth() &&
                        job.dateObj.getFullYear() === date.getFullYear()) {

                        const p = document.createElement("p"); //create paragraph element
                        p.className = "job-item"; //add class for styling
                        p.textContent = `${job.clientName} – ${job.serviceName} – ${job.address} (${job.status})`; //set text content
                        cell.appendChild(p); //add paragraph to cell
                    }
                }
            }
            row.appendChild(cell); //add cell to row
            currentDay++; //move to next day
        }
        tbody.appendChild(row); //add row to month tbody
        if (currentDay > daysInMonth) break; //stop if month is complete
    }
}
