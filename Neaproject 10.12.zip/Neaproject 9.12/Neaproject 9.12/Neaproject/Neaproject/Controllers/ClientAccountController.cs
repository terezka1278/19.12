﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Models;
using Neaproject.Dtos;
using Neaproject.Methods;

namespace Neaproject.Controllers
{
    [ApiController]
    [Route("api/client-account")]
    public class ClientAccountController : ControllerBase
    {
        private readonly SqliteDataAccess _db;
        public ClientAccountController(SqliteDataAccess db)
        {
            _db = db;
        }

        [HttpGet("{clientId}")] //get client info
        public ActionResult<Client> GetClient(string clientId)
        {
            var client = _db.GetClientById(clientId); //get client records
            if (client == null) //if no client exists
                return NotFound("Client not found"); //output error message
            return Ok(client); //return full client object
        }

        [HttpPut("{clientId}")] //update client files
        public IActionResult UpdateClient(string clientId, [FromBody] ClientUpdate updated)
        {
            string? hashed; //holds password hash and can be null
            if (updated.Password == null) //if no new password
            {
                hashed = null; //no password change
            }
            else //if new password provided
            {
                hashed = PasswordHasher.Hash(updated.Password); //hash using PasswordHasher
            }

                _db.UpdateClientFields( //update database
                clientId,
                updated.Email,
                updated.PhoneNum,
                updated.Address,
                updated.Postcode,
                hashed
            );
            return Ok(new { message = "Account updated successfully." }); //output success response
        }
    }
}