﻿using Microsoft.AspNetCore.Mvc;
using Neaproject.Data;
using Neaproject.Dtos;
using System.Collections.Generic;

namespace Neaproject.Controllers
{
    [ApiController] 
    [Route("api/business/documents")]
    public class BusinessDocumentsController : ControllerBase
    {
        private readonly SqliteDataAccess _db;

        public BusinessDocumentsController(SqliteDataAccess db)
        {
            _db = db; //database access
        } 

        [HttpGet("quotes")] //route to get quotes
        public ActionResult<IEnumerable<ClientQuote>> GetAllQuotes() //returns list of client quotes
        {
            var quotes = _db.GetAllQuotes(); //call database methods
            return Ok(quotes); //return list
        }

        [HttpGet("invoices")] //rout to get invoices
        public ActionResult<IEnumerable<ClientInvoice>> GetAllInvoices()  //returns list of client invoices
        {
            var invoices = _db.GetAllInvoices(); //call database methods
            return Ok(invoices); //return list
        }
    }
}
